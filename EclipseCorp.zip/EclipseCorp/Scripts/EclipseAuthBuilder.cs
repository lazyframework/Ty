using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

// Layar Masuk (Login) dan Daftar (Register) Project Eclipse.
// Satu layar dengan dua tab. Validasi form sudah ada. Hubungkan ke backend lewat event
// On Login / On Register, atau pakai "Use Local Demo Accounts" untuk uji coba tanpa server.
public class EclipseAuthBuilder : MonoBehaviour
{
    [Header("Navigasi scene")]
    public string lobbySceneName = "EclipseLobby";
    public bool loadSceneOnSuccess = true;
    [Tooltip("Nama tampilan pemain disimpan di PlayerPrefs dengan kunci ini (lobby bisa membacanya).")]
    public string playerNamePrefsKey = "EclipsePlayerName";

    [Header("Opsional: gambar sendiri (kosong = placeholder)")]
    public Font font;
    public Sprite background;
    public Sprite logo;

    [Header("Teks")]
    public string versionText = "v1.0.0";
    public int minPasswordLength = 6;
    public int minUsernameLength = 3;
    public bool startOnRegister = false;

    [Header("Akun uji coba lokal (HANYA untuk demo, bukan untuk produksi)")]
    public bool useLocalDemoAccounts = true;

    [Header("Mode server (diatur otomatis oleh EclipseFirebaseAuth)")]
    [Tooltip("Login hanya dengan email (Firebase tidak mendukung login username).")]
    public bool loginWithEmailOnly = false;
    [Tooltip("Tombol Guest ditangani skrip lain (mis. Firebase anonymous).")]
    public bool handleGuestExternally = false;

    [Serializable] public class LoginEvent : UnityEvent<string, string> { }
    [Serializable] public class RegisterEvent : UnityEvent<string, string, string> { }
    [Serializable] public class StringEvent : UnityEvent<string> { }
    [Tooltip("(email/username, password) setelah lolos validasi.")]
    public LoginEvent onLogin = new LoginEvent();
    [Tooltip("(username, email, password) setelah lolos validasi.")]
    public RegisterEvent onRegister = new RegisterEvent();
    public UnityEvent onGuest = new UnityEvent();
    public UnityEvent onForgotPassword = new UnityEvent();
    [Tooltip("Dipanggil dengan nama tampilan saat masuk/daftar berhasil.")]
    public StringEvent onAuthSuccess = new StringEvent();

    public Color cyan = new Color(.15f, .65f, 1, 1);

    public enum BackdropMode { Stretch, Cover }
    [Header("Latar layar penuh")]
    public BackdropMode backdropMode = BackdropMode.Stretch;

    const string Root = "EclipseAuthCanvas_v1";

    RectTransform frame;
    readonly Dictionary<Transform, Vector2> origin = new Dictionary<Transform, Vector2>();
    bool registerMode;

    enum HA { Left, Center, Right }
    enum VA { Top, Center, Bottom }
    HA ha = HA.Center;
    VA va = VA.Center;

    static Sprite sFill, sLine, sGlow;

    static readonly Color Txt = new Color(.92f, .96f, 1f);
    static readonly Color Dim = new Color(.62f, .74f, .9f);
    static readonly Color PanelFill = new Color(.02f, .06f, .14f, .90f);
    static readonly Color PanelLine = new Color(.24f, .48f, .82f, .95f);
    static readonly Color BrightFill = new Color(.03f, .30f, .88f, .96f);
    static readonly Color BrightLine = new Color(.40f, .78f, 1f, 1f);
    static readonly Color FieldFill = new Color(.015f, .045f, .12f, .98f);
    static readonly Color ErrorColor = new Color(1f, .42f, .42f);
    static readonly Color OkColor = new Color(.45f, .9f, .6f);

    // ---------------------------------------------------------------- lifecycle

    void Start()
    {
        var root = transform.Find(Root);
        if (root == null) Build();
        else
        {
            foreach (var b in root.GetComponentsInChildren<Button>(true))
            {
                string id = b.gameObject.name;
                b.onClick.RemoveAllListeners();
                b.onClick.AddListener(() => Route(id));
            }
        }
        registerMode = startOnRegister;
        if (Application.isPlaying) RestoreRemembered();
        Refresh();
    }

#if UNITY_EDITOR
    void Reset()
    {
        UnityEditor.EditorApplication.delayCall += () => { if (this != null && transform.Find(Root) == null) Build(); };
    }
#endif

    // ---------------------------------------------------------------- state

    public string LoginIdentityText { get { return Val("LoginIdentity"); } }
    public void ShowLogin() { registerMode = false; Refresh(); }
    public void ShowRegister() { registerMode = true; Refresh(); }

    Transform FindDeep(string n)
    {
        var root = transform.Find(Root);
        if (root == null) return null;
        foreach (var t in root.GetComponentsInChildren<Transform>(true))
            if (t.name == n) return t;
        return null;
    }

    void SetText(string n, string v)
    {
        var t = FindDeep(n);
        if (t == null) return;
        var tx = t.GetComponent<Text>();
        if (tx != null) tx.text = v;
    }

    InputField GetInput(string n)
    {
        var t = FindDeep(n);
        return t != null ? t.GetComponent<InputField>() : null;
    }

    string Val(string n)
    {
        var f = GetInput(n);
        return f != null ? f.text : "";
    }

    bool Checked(string n)
    {
        var t = FindDeep(n);
        var tg = t != null ? t.GetComponent<Toggle>() : null;
        return tg != null && tg.isOn;
    }

    public void Refresh()
    {
        if (transform.Find(Root) == null) return;
        var lf = FindDeep("LoginForm");
        var rf = FindDeep("RegisterForm");
        if (lf != null) lf.gameObject.SetActive(!registerMode);
        if (rf != null) rf.gameObject.SetActive(registerMode);

        SetText("AuthTitle", registerMode ? "REGISTER" : "LOGIN");
        SetText("AuthSubtitle", registerMode ? "Create your agent account." : "Sign in to continue your mission.");
        SetText("AuthVersion", versionText);
        SetText("LoginIdentityLabel", loginWithEmailOnly ? "EMAIL" : "EMAIL OR USERNAME");
        SetText("LoginIdentityPlaceholder", loginWithEmailOnly ? "Enter your email" : "Enter your email or username");
        SetTab("TabLogin", !registerMode);
        SetTab("TabRegister", registerMode);

        var lg = FindDeep("Logo");
        if (lg != null)
        {
            var im = lg.GetComponent<Image>();
            if (im != null && im.sprite != logo) { im.sprite = logo; im.enabled = logo != null; }
        }
    }

    void SetTab(string id, bool active)
    {
        var t = FindDeep(id);
        if (t == null) return;
        var f = t.Find("Fill");
        var o = t.Find("Outline");
        if (f != null) f.GetComponent<Image>().color = active ? BrightFill : new Color(.02f, .06f, .14f, .7f);
        if (o != null) o.GetComponent<Image>().color = active ? BrightLine : new Color(.24f, .48f, .82f, .5f);
        var l = t.Find(id + "Label");
        if (l != null) l.GetComponent<Text>().color = active ? Color.white : Dim;
    }

    // ---------------------------------------------------------------- routing

    public void Route(string id)
    {
        if (id == "TabLogin") { ShowLogin(); ClearMessages(); }
        else if (id == "TabRegister") { ShowRegister(); ClearMessages(); }
        else if (id == "LoginSubmit") SubmitLogin();
        else if (id == "RegisterSubmit") SubmitRegister();
        else if (id == "Guest") { onGuest.Invoke(); if (!handleGuestExternally) Success("Guest"); }
        else if (id == "Forgot") onForgotPassword.Invoke();
        else if (id == "ShowLoginPassword") TogglePassword("LoginPassword", "ShowLoginPassword");
        else if (id == "ShowRegPassword") TogglePassword("RegPassword", "ShowRegPassword");
        else if (id == "ShowRegConfirm") TogglePassword("RegConfirm", "ShowRegConfirm");
    }

    void TogglePassword(string field, string button)
    {
        var f = GetInput(field);
        if (f == null) return;
        bool hide = f.contentType != InputField.ContentType.Password;
        f.contentType = hide ? InputField.ContentType.Password : InputField.ContentType.Standard;
        f.ForceLabelUpdate();
        SetText(button + "Label", hide ? "SHOW" : "HIDE");
    }

    // ---------------------------------------------------------------- pesan

    public void ShowError(string msg) { Message(msg, true); }
    public void ShowInfo(string msg) { Message(msg, false); }

    void Message(string msg, bool error)
    {
        foreach (var n in new[] { "LoginMessage", "RegisterMessage" })
        {
            var t = FindDeep(n);
            if (t == null) continue;
            var tx = t.GetComponent<Text>();
            if (tx == null) continue;
            tx.text = msg;
            tx.color = error ? ErrorColor : OkColor;
        }
    }

    void ClearMessages() { Message("", false); }

    // ---------------------------------------------------------------- validasi + submit

    static bool ValidEmail(string e)
    {
        return Regex.IsMatch(e ?? "", @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
    }

    void SubmitLogin()
    {
        string id = Val("LoginIdentity").Trim();
        string pw = Val("LoginPassword");
        if (id.Length == 0) { ShowError("Enter your email or username."); return; }
        if (pw.Length == 0) { ShowError("Enter your password."); return; }
        if (loginWithEmailOnly && !ValidEmail(id)) { ShowError("Enter your email address."); return; }

        RememberIdentity(id);
        onLogin.Invoke(id, pw);
        if (useLocalDemoAccounts) LocalLogin(id, pw);
    }

    void SubmitRegister()
    {
        string user = Val("RegUsername").Trim();
        string mail = Val("RegEmail").Trim();
        string pw = Val("RegPassword");
        string pw2 = Val("RegConfirm");

        if (user.Length < minUsernameLength) { ShowError("Username must be at least " + minUsernameLength + " characters."); return; }
        if (!Regex.IsMatch(user, @"^[A-Za-z0-9_\-\.]+$")) { ShowError("Username may only contain letters, numbers, _ - ."); return; }
        if (!ValidEmail(mail)) { ShowError("Enter a valid email address."); return; }
        if (pw.Length < minPasswordLength) { ShowError("Password must be at least " + minPasswordLength + " characters."); return; }
        if (pw != pw2) { ShowError("Passwords do not match."); return; }
        if (!Checked("AcceptTerms")) { ShowError("Please accept the Terms of Service."); return; }

        onRegister.Invoke(user, mail, pw);
        if (useLocalDemoAccounts) LocalRegister(user, mail, pw);
    }

    // ---------------------------------------------------------------- akun lokal (demo)

    static string KeyUser(string u) { return "eclipse_user_" + u.Trim().ToLowerInvariant(); }
    static string KeyMail(string m) { return "eclipse_mail_" + m.Trim().ToLowerInvariant(); }

    static string NewSalt()
    {
        var b = new byte[16];
        using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create()) rng.GetBytes(b);
        return Convert.ToBase64String(b);
    }

    static string Hash(string pass, string salt)
    {
        using (var sha = System.Security.Cryptography.SHA256.Create())
            return Convert.ToBase64String(sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(salt + pass)));
    }

    void LocalRegister(string user, string mail, string pw)
    {
        if (PlayerPrefs.HasKey(KeyUser(user))) { ShowError("Username is already taken."); return; }
        if (PlayerPrefs.HasKey(KeyMail(mail))) { ShowError("Email is already registered."); return; }
        string salt = NewSalt();
        PlayerPrefs.SetString(KeyUser(user), salt + "|" + Hash(pw, salt) + "|" + mail + "|" + user);
        PlayerPrefs.SetString(KeyMail(mail), user);
        PlayerPrefs.Save();
        Success(user);
    }

    void LocalLogin(string id, string pw)
    {
        string user = id;
        if (id.Contains("@"))
        {
            if (!PlayerPrefs.HasKey(KeyMail(id))) { ShowError("Account not found."); return; }
            user = PlayerPrefs.GetString(KeyMail(id));
        }
        if (!PlayerPrefs.HasKey(KeyUser(user))) { ShowError("Account not found."); return; }
        var parts = PlayerPrefs.GetString(KeyUser(user)).Split('|');
        if (parts.Length < 4 || Hash(pw, parts[0]) != parts[1]) { ShowError("Wrong password."); return; }
        Success(parts[3]);
    }

    // ---------------------------------------------------------------- sukses / ingat saya

    // Panggil ini dari backend-mu saat masuk/daftar berhasil.
    public void Success(string displayName)
    {
        if (!string.IsNullOrEmpty(playerNamePrefsKey)) PlayerPrefs.SetString(playerNamePrefsKey, displayName);
        PlayerPrefs.Save();
        ShowInfo("Welcome, " + displayName + "!");
        onAuthSuccess.Invoke(displayName);
        if (loadSceneOnSuccess && !string.IsNullOrEmpty(lobbySceneName))
        {
            if (Application.CanStreamedLevelBeLoaded(lobbySceneName)) SceneManager.LoadScene(lobbySceneName);
            else Debug.LogError("Scene '" + lobbySceneName + "' belum ada di File > Build Profiles > Scene List.", this);
        }
    }

    void RememberIdentity(string id)
    {
        if (Checked("RememberMe")) PlayerPrefs.SetString("eclipse_last_identity", id);
        else PlayerPrefs.DeleteKey("eclipse_last_identity");
    }

    void RestoreRemembered()
    {
        if (!PlayerPrefs.HasKey("eclipse_last_identity")) return;
        var f = GetInput("LoginIdentity");
        if (f != null) f.text = PlayerPrefs.GetString("eclipse_last_identity");
        var t = FindDeep("RememberMe");
        var tg = t != null ? t.GetComponent<Toggle>() : null;
        if (tg != null) tg.isOn = true;
    }

    // ---------------------------------------------------------------- helpers

    RectTransform NewRT(Transform p, string n)
    {
        var rt = new GameObject(n, typeof(RectTransform)).GetComponent<RectTransform>();
        rt.SetParent(p, false);
        return rt;
    }

    RectTransform R(Transform p, string n, float x, float y, float w, float h)
    {
        var r = NewRT(p, n);
        Vector2 o;
        origin.TryGetValue(p, out o);
        r.pivot = new Vector2(0, 1);
        if (p == frame)
        {
            float ax = ha == HA.Left ? 0 : (ha == HA.Right ? 1672 : 836);
            float ay = va == VA.Top ? 0 : (va == VA.Bottom ? 941 : 470.5f);
            r.anchorMin = r.anchorMax = new Vector2(ha == HA.Left ? 0 : (ha == HA.Right ? 1 : .5f),
                                                    va == VA.Top ? 1 : (va == VA.Bottom ? 0 : .5f));
            r.anchoredPosition = new Vector2(x - ax, -(y - ay));
        }
        else
        {
            r.anchorMin = r.anchorMax = new Vector2(0, 1);
            r.anchoredPosition = new Vector2(x - o.x, -(y - o.y));
        }
        r.sizeDelta = new Vector2(w, h);
        origin[r] = new Vector2(x, y);
        return r;
    }

    Image Img(Transform p, string n, float x, float y, float w, float h, Sprite s, Color c, bool sliced = false, bool ray = false)
    {
        var i = R(p, n, x, y, w, h).gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = c;
        i.raycastTarget = ray;
        if (s != null)
        {
            if (sliced) i.type = Image.Type.Sliced;
            else i.preserveAspect = true;
        }
        return i;
    }

    Image S(Transform p, string n, float x, float y, float w, float h, Color c) { return Img(p, n, x, y, w, h, null, c); }

    Text T(Transform p, string n, string s, float x, float cy, float w, int size, bool bold = false,
           TextAnchor a = TextAnchor.MiddleLeft, bool italic = false, Color? col = null)
    {
        float h = size * 1.6f;
        var t = R(p, n, x, cy - h / 2f, w, h).gameObject.AddComponent<Text>();
        t.font = font;
        t.text = s;
        t.fontSize = size;
        t.fontStyle = bold ? (italic ? FontStyle.BoldAndItalic : FontStyle.Bold) : (italic ? FontStyle.Italic : FontStyle.Normal);
        t.color = col ?? Txt;
        t.alignment = a;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    RectTransform Panel(Transform p, string n, float x, float y, float w, float h, Color fill, Color line, float glow = 0)
    {
        var r = R(p, n, x, y, w, h);
        if (glow > 0) Img(r, "Glow", x - 20, y - 20, w + 40, h + 40, GlowSprite(), new Color(.1f, .5f, 1f, glow), true);
        Img(r, "Fill", x, y, w, h, FillSprite(), fill, true);
        Img(r, "Outline", x, y, w, h, LineSprite(), line, true);
        return r;
    }

    void Click(RectTransform root)
    {
        Graphic target = null;
        var outline = root.Find("Outline");
        if (outline != null) target = outline.GetComponent<Graphic>();
        var fill = root.Find("Fill");
        if (fill != null) fill.GetComponent<Graphic>().raycastTarget = true;
        else
        {
            var hit = NewRT(root, "Hit");
            hit.anchorMin = Vector2.zero; hit.anchorMax = Vector2.one; hit.offsetMin = hit.offsetMax = Vector2.zero;
            var im = hit.gameObject.AddComponent<Image>();
            im.color = new Color(0, 0, 0, 0);
            im.raycastTarget = true;
            if (target == null) target = root.GetComponentInChildren<Text>();
            if (target == null) target = im;
        }
        var b = root.gameObject.AddComponent<Button>();
        b.targetGraphic = target;
        var c = b.colors;
        c.normalColor = new Color(.88f, .92f, 1f, 1f);
        c.highlightedColor = Color.white;
        c.pressedColor = new Color(.6f, .78f, 1f, 1f);
        c.selectedColor = Color.white;
        c.fadeDuration = .1f;
        b.colors = c;
        string id = root.name;
        b.onClick.AddListener(() => Route(id));
    }

    // kolom input (legacy InputField)
    InputField Field(Transform p, string id, float x, float y, float w, float h, string placeholder, bool password, string showButtonId = null)
    {
        var root = Panel(p, id, x, y, w, h, FieldFill, new Color(.24f, .48f, .82f, .8f));
        root.Find("Fill").GetComponent<Graphic>().raycastTarget = true;
        float right = password ? 78 : 14;

        var text = T(root, id + "Text", "", x + 14, y + h / 2f, w - 14 - right, 18, false, TextAnchor.MiddleLeft);
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Truncate;
        text.supportRichText = false;
        var ph = T(root, id + "Placeholder", placeholder, x + 14, y + h / 2f, w - 14 - right, 18, false, TextAnchor.MiddleLeft, true, new Color(.55f, .68f, .88f, .6f));
        ph.horizontalOverflow = HorizontalWrapMode.Wrap;
        ph.verticalOverflow = VerticalWrapMode.Truncate;

        var inp = root.gameObject.AddComponent<InputField>();
        inp.targetGraphic = root.Find("Fill").GetComponent<Graphic>();
        inp.transition = Selectable.Transition.None;
        inp.textComponent = text;
        inp.placeholder = ph;
        inp.lineType = InputField.LineType.SingleLine;
        inp.contentType = password ? InputField.ContentType.Password : InputField.ContentType.Standard;
        inp.caretColor = Color.white;
        inp.selectionColor = new Color(.2f, .55f, 1f, .45f);

        if (password && showButtonId != null)
        {
            var b = R(root, showButtonId, x + w - 70, y + 6, 64, h - 12);
            T(b, showButtonId + "Label", "SHOW", x + w - 70, y + h / 2f, 64, 12, true, TextAnchor.MiddleCenter, false, new Color(.45f, .8f, 1f));
            Click(b);
        }
        return inp;
    }

    void Label(Transform p, string n, string s, float x, float cy)
    {
        T(p, n, s, x, cy, 300, 12, true, TextAnchor.MiddleLeft, false, Dim);
    }

    // kotak centang
    void Check(Transform p, string id, float x, float y, string label)
    {
        var r = R(p, id, x, y, 24, 24);
        var bg = Img(r, id + "Box", x, y, 24, 24, FillSprite(), FieldFill, true, true);
        Img(r, id + "BoxLine", x, y, 24, 24, LineSprite(), PanelLine, true);
        var mark = Img(r, id + "Mark", x + 6, y + 6, 12, 12, null, cyan);
        var tg = r.gameObject.AddComponent<Toggle>();
        tg.targetGraphic = bg;
        tg.graphic = mark;
        tg.isOn = false;
        T(p, id + "Label", label, x + 34, y + 12, 380, 14, false, TextAnchor.MiddleLeft, false, new Color(.85f, .92f, 1f));
    }

    // ---------------------------------------------------------------- latar & sprite

    void BackdropStretch()
    {
        var parent = frame.parent;
        var cont = new GameObject("BackdropRoot", typeof(RectTransform), typeof(RectMask2D));
        cont.transform.SetParent(parent, false);
        cont.transform.SetAsFirstSibling();
        var cr = cont.GetComponent<RectTransform>();
        cr.anchorMin = Vector2.zero; cr.anchorMax = Vector2.one; cr.offsetMin = cr.offsetMax = Vector2.zero;

        var solid = new GameObject("BackdropSolid", typeof(RectTransform), typeof(Image));
        solid.transform.SetParent(cont.transform, false);
        var sr = solid.GetComponent<RectTransform>();
        sr.anchorMin = Vector2.zero; sr.anchorMax = Vector2.one; sr.offsetMin = sr.offsetMax = Vector2.zero;
        var si = solid.GetComponent<Image>();
        si.color = new Color(.015f, .048f, .105f);
        si.raycastTarget = false;

        var bg = new GameObject("Backdrop", typeof(RectTransform), typeof(Image), typeof(EclipseIconSlot));
        bg.transform.SetParent(cont.transform, false);
        var img = bg.GetComponent<Image>();
        img.sprite = background;
        img.color = Color.white;
        img.raycastTarget = false;
        img.preserveAspect = false;
        var br = bg.GetComponent<RectTransform>();
        if (backdropMode == BackdropMode.Cover)
        {
            var fit = bg.AddComponent<AspectRatioFitter>();
            fit.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            fit.aspectRatio = 1672f / 941f;
        }
        else
        {
            br.anchorMin = Vector2.zero; br.anchorMax = Vector2.one; br.offsetMin = br.offsetMax = Vector2.zero;
        }

        // peredam supaya latar tetap terbaca di belakang kartu
        var dim = new GameObject("BackdropDim", typeof(RectTransform), typeof(Image));
        dim.transform.SetParent(cont.transform, false);
        var dr = dim.GetComponent<RectTransform>();
        dr.anchorMin = Vector2.zero; dr.anchorMax = Vector2.one; dr.offsetMin = dr.offsetMax = Vector2.zero;
        var di = dim.GetComponent<Image>();
        di.color = new Color(0, .01f, .04f, .35f);
        di.raycastTarget = false;
    }

    static float Sd(float x, float y, float x0, float y0, float x1, float y1, float c)
    {
        float d = Mathf.Min(Mathf.Min(x - x0, x1 - x), Mathf.Min(y - y0, y1 - y));
        float tl = ((x - x0) + (y1 - y) - c) * 0.70710678f;
        float br = ((x1 - x) + (y - y0) - c) * 0.70710678f;
        return Mathf.Min(d, Mathf.Min(tl, br));
    }

    static Sprite Make(string name, int w, int h, int border, Func<float, float, Color> px)
    {
#if UNITY_EDITOR
        const string dir = "Assets/EclipseLobby/Generated";
        string path = dir + "/" + name + ".png";
        var existing = UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (existing != null) return existing;
#endif
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.name = name;
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        var cols = new Color32[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                cols[y * w + x] = px(x + .5f, y + .5f);
        t.SetPixels32(cols);
        t.Apply();
#if UNITY_EDITOR
        System.IO.Directory.CreateDirectory(dir);
        System.IO.File.WriteAllBytes(path, t.EncodeToPNG());
        UnityEngine.Object.DestroyImmediate(t);
        UnityEditor.AssetDatabase.ImportAsset(path, UnityEditor.ImportAssetOptions.ForceSynchronousImport);
        var ti = (UnityEditor.TextureImporter)UnityEditor.AssetImporter.GetAtPath(path);
        ti.textureType = UnityEditor.TextureImporterType.Sprite;
        ti.spriteImportMode = UnityEditor.SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 100;
        ti.spriteBorder = new Vector4(border, border, border, border);
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.filterMode = FilterMode.Bilinear;
        ti.textureCompression = UnityEditor.TextureImporterCompression.Uncompressed;
        ti.SaveAndReimport();
        return UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
#else
        var s = Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect,
                              new Vector4(border, border, border, border));
        s.name = name;
        return s;
#endif
    }

    static Sprite FillSprite()
    {
        if (sFill == null)
            sFill = Make("EclipseFill", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f);
                float g = Mathf.Lerp(.72f, 1f, y / 64f);
                return new Color(g, g, g, a);
            });
        return sFill;
    }

    static Sprite LineSprite()
    {
        if (sLine == null)
            sLine = Make("EclipseLine", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f) * Mathf.Clamp01(2.1f - d);
                return new Color(1, 1, 1, a);
            });
        return sLine;
    }

    static Sprite GlowSprite()
    {
        if (sGlow == null)
            sGlow = Make("EclipseGlow", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 20, 20, 44, 44, 12);
                float a = d >= 0 ? 1f : Mathf.Pow(Mathf.Clamp01(1f + d / 20f), 2.2f);
                return new Color(1, 1, 1, a);
            });
        return sGlow;
    }

    // ---------------------------------------------------------------- build

    [ContextMenu("Build Login Register")]
    public void Build()
    {
        Transform old;
        while ((old = transform.Find(Root)) != null)
        {
            old.gameObject.SetActive(false);
            old.SetParent(null);
            if (Application.isPlaying) Destroy(old.gameObject);
            else DestroyImmediate(old.gameObject);
        }
        origin.Clear();

        if (font == null)
        {
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        var go = new GameObject(Root, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.transform.SetParent(transform, false);
        go.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scale = go.GetComponent<CanvasScaler>();
        scale.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scale.referenceResolution = new Vector2(1672, 941);
        scale.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;

        frame = new GameObject("ReferenceFrame", typeof(RectTransform)).GetComponent<RectTransform>();
        frame.SetParent(go.transform, false);
        frame.anchorMin = Vector2.zero;
        frame.anchorMax = Vector2.one;
        frame.offsetMin = frame.offsetMax = Vector2.zero;
        frame.gameObject.AddComponent<EclipseSafeArea>();
        origin[frame] = Vector2.zero;

        BackdropStretch();
        ha = HA.Center; va = VA.Center;
        BuildCard();

        ha = HA.Center; va = VA.Bottom;
        T(frame, "AuthVersion", "", 636, 915, 400, 11, false, TextAnchor.MiddleCenter, false, Dim);

#if UNITY_2023_1_OR_NEWER
        bool noES = UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null;
#else
        bool noES = UnityEngine.Object.FindObjectOfType<EventSystem>() == null;
#endif
        if (noES)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        registerMode = startOnRegister;
        Refresh();
    }

    void BuildCard()
    {
        // kartu 500 x 700, di tengah layar
        var card = Panel(frame, "AuthCard", 586, 110, 500, 700, new Color(.01f, .04f, .11f, .92f), new Color(.24f, .48f, .82f, .9f), .5f);
        foreach (var g in card.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        var logoImg = Img(card, "Logo", 786, 124, 100, 72, null, Color.white);
        logoImg.preserveAspect = true;
        logoImg.gameObject.AddComponent<EclipseIconSlot>();

        T(card, "AuthTitle", "LOGIN", 586, 222, 500, 32, true, TextAnchor.MiddleCenter, true);
        T(card, "AuthSubtitle", "", 586, 252, 500, 15, false, TextAnchor.MiddleCenter, false, Dim);

        // tab
        var t1 = Panel(card, "TabLogin", 611, 274, 224, 42, BrightFill, BrightLine);
        T(t1, "TabLoginLabel", "LOGIN", 611, 295, 224, 16, true, TextAnchor.MiddleCenter);
        Click(t1);
        var t2 = Panel(card, "TabRegister", 837, 274, 224, 42, PanelFill, PanelLine);
        T(t2, "TabRegisterLabel", "REGISTER", 837, 295, 224, 16, true, TextAnchor.MiddleCenter);
        Click(t2);

        BuildLogin(card);
        BuildRegister(card);
    }

    void BuildLogin(RectTransform card)
    {
        var f = R(card, "LoginForm", 611, 336, 450, 440);

        Label(f, "LoginIdentityLabel", "EMAIL OR USERNAME", 611, 346);
        Field(f, "LoginIdentity", 611, 358, 450, 48, "Enter your email or username", false);

        Label(f, "LoginPasswordLabel", "PASSWORD", 611, 434);
        Field(f, "LoginPassword", 611, 446, 450, 48, "Enter your password", true, "ShowLoginPassword");

        Check(f, "RememberMe", 611, 512, "Remember me");
        var fg = R(f, "Forgot", 861, 506, 200, 36);
        T(fg, "ForgotLabel", "Forgot password?", 861, 524, 200, 14, false, TextAnchor.MiddleRight, false, new Color(.45f, .8f, 1f));
        Click(fg);

        T(f, "LoginMessage", "", 611, 566, 450, 14, false, TextAnchor.MiddleCenter, false, ErrorColor);

        var b = Panel(f, "LoginSubmit", 611, 590, 450, 54, BrightFill, BrightLine, .6f);
        T(b, "LoginSubmitLabel", "LOGIN", 611, 617, 450, 20, true, TextAnchor.MiddleCenter, true);
        Click(b);

        S(f, "OrLineL", 611, 680, 190, 1, new Color(.2f, .4f, .7f, .6f));
        T(f, "OrText", "OR", 801, 680, 70, 12, true, TextAnchor.MiddleCenter, false, Dim);
        S(f, "OrLineR", 871, 680, 190, 1, new Color(.2f, .4f, .7f, .6f));

        var g = Panel(f, "Guest", 611, 702, 450, 48, new Color(.02f, .07f, .17f, .9f), PanelLine);
        T(g, "GuestLabel", "PLAY AS GUEST", 611, 726, 450, 16, true, TextAnchor.MiddleCenter);
        Click(g);
    }

    void BuildRegister(RectTransform card)
    {
        var f = R(card, "RegisterForm", 611, 336, 450, 440);

        Label(f, "RegUsernameLabel", "USERNAME", 611, 346);
        Field(f, "RegUsername", 611, 358, 450, 44, "Choose a username", false);

        Label(f, "RegEmailLabel", "EMAIL", 611, 420);
        Field(f, "RegEmail", 611, 432, 450, 44, "Enter your email", false);

        Label(f, "RegPasswordLabel", "PASSWORD", 611, 494);
        Field(f, "RegPassword", 611, 506, 450, 44, "Create a password", true, "ShowRegPassword");

        Label(f, "RegConfirmLabel", "CONFIRM PASSWORD", 611, 568);
        Field(f, "RegConfirm", 611, 580, 450, 44, "Repeat your password", true, "ShowRegConfirm");

        Check(f, "AcceptTerms", 611, 638, "I agree to the Terms of Service and Privacy Policy");

        T(f, "RegisterMessage", "", 611, 686, 450, 14, false, TextAnchor.MiddleCenter, false, ErrorColor);

        var b = Panel(f, "RegisterSubmit", 611, 706, 450, 54, BrightFill, BrightLine, .6f);
        T(b, "RegisterSubmitLabel", "CREATE ACCOUNT", 611, 733, 450, 20, true, TextAnchor.MiddleCenter, true);
        Click(b);
    }
}
