using UnityEngine;
using UnityEngine.Rendering;

// Panggung 3D untuk pratinjau karakter di layar Select Character.
// Membuat kamera + lampu kecil jauh dari scene (tidak mengganggu objek lain), merender ke RenderTexture
// yang ditampilkan oleh RawImage "CharacterModel". Model diganti lewat Show().
public class EclipseCharacterStage : MonoBehaviour
{
    [Header("Panggung")]
    public Vector3 anchor = new Vector3(5000, 5000, 5000);
    public Vector2Int textureSize = new Vector2Int(1024, 1280);
    public float cameraDistance = 3.4f;
    public float cameraHeight = 1.0f;
    public float lookHeight = 0.95f;
    public float fieldOfView = 30f;

    [Header("Putar")]
    public float autoSpin = 12f;
    public float resumeSpinDelay = 2f;

    [Header("Placeholder (saat model belum ada)")]
    public bool placeholderWhenEmpty = true;
    public Color placeholderColor = new Color(.3f, .5f, .9f);

    public RenderTexture Target { get; private set; }

    GameObject rig;
    Transform spawn;
    GameObject current;
    bool ownsTarget;
    float idle;

    public void Init(RenderTexture external)
    {
        if (rig != null) return;
        if (external != null) Target = external;
        else
        {
            Target = new RenderTexture(textureSize.x, textureSize.y, 24, RenderTextureFormat.ARGB32);
            Target.name = "EclipseCharacterStage";
            ownsTarget = true;
        }

        rig = new GameObject("EclipseCharacterStageRig");
        rig.transform.position = anchor;
        spawn = new GameObject("Spawn").transform;
        spawn.SetParent(rig.transform, false);

        var cgo = new GameObject("StageCamera");
        cgo.transform.SetParent(rig.transform, false);
        cgo.transform.localPosition = new Vector3(0, cameraHeight, -cameraDistance);
        cgo.transform.LookAt(rig.transform.position + new Vector3(0, lookHeight, 0));
        var cam = cgo.AddComponent<Camera>();
        cam.targetTexture = Target;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0, 0, 0, 0);
        cam.fieldOfView = fieldOfView;
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 30f;
        cam.allowHDR = false;
        cam.allowMSAA = false;
        cam.depth = -100;

        AddLight("Key", new Vector3(2f, 2.5f, -2f), new Color(.85f, .92f, 1f), 2.2f);
        AddLight("Fill", new Vector3(-2.5f, 1.2f, -1.5f), new Color(.3f, .5f, 1f), 1.6f);
        AddLight("Rim", new Vector3(0f, 2.5f, 2.5f), new Color(.4f, .7f, 1f), 2.6f);
    }

    void AddLight(string n, Vector3 pos, Color c, float intensity)
    {
        var go = new GameObject(n);
        go.transform.SetParent(rig.transform, false);
        go.transform.localPosition = pos;
        var l = go.AddComponent<Light>();
        l.type = LightType.Point;
        l.color = c;
        l.intensity = intensity;
        l.range = 14f;
        l.shadows = LightShadows.None;
    }

    // Ganti model. prefab null + allowPlaceholder = tampilkan kapsul biru sebagai penanda.
    public void Show(GameObject prefab, bool allowPlaceholder, int index = 0)
    {
        if (rig == null) return;
        if (current != null) { Destroy(current); current = null; }
        spawn.localRotation = Quaternion.identity;

        if (prefab != null)
        {
            current = Instantiate(prefab, spawn);
            current.transform.localPosition = Vector3.zero;
            current.transform.localRotation = Quaternion.identity;
        }
        else if (allowPlaceholder && placeholderWhenEmpty)
        {
            current = MakePlaceholder(index);
        }
    }

    GameObject MakePlaceholder(int index)
    {
        var root = new GameObject("Placeholder");
        root.transform.SetParent(spawn, false);
        var cap = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        cap.transform.SetParent(root.transform, false);
        cap.transform.localPosition = new Vector3(0, 1f, 0);
        cap.transform.localScale = new Vector3(.6f, 1f, .6f);
        var col = cap.GetComponent<Collider>();
        if (col != null) Destroy(col);

        Shader sh = GraphicsSettings.currentRenderPipeline != null
            ? Shader.Find("Universal Render Pipeline/Lit")
            : Shader.Find("Standard");
        if (sh == null) sh = Shader.Find("Sprites/Default");
        if (sh != null)
        {
            var m = new Material(sh);
            m.color = Color.HSVToRGB(Mathf.Repeat(.58f + index * .17f, 1f), .55f, .9f);
            cap.GetComponent<Renderer>().material = m;
        }
        return root;
    }

    public void Rotate(float degrees)
    {
        if (spawn == null) return;
        spawn.Rotate(0, degrees, 0);
        idle = resumeSpinDelay;
    }

    void Update()
    {
        if (spawn == null) return;
        if (idle > 0) { idle -= Time.deltaTime; return; }
        if (autoSpin != 0) spawn.Rotate(0, autoSpin * Time.deltaTime, 0);
    }

    void OnDestroy()
    {
        if (rig != null) Destroy(rig);
        if (ownsTarget && Target != null) { Target.Release(); Destroy(Target); }
    }
}
