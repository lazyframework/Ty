using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

[Serializable]
public class EclipseModeRow
{
    public Sprite icon;
    public string text;
    public EclipseModeRow() { }
    public EclipseModeRow(string t) { text = t; }
}

[Serializable]
public class EclipseModeData
{
    public string title = "CAMPAIGN";
    [TextArea(2, 3)] public string description = "";
    public string tag = "";
    public bool tagGold = false;
    public Sprite cardArt;

    [Header("Baris info (maks 3, atau 2 bila ada Difficulty)")]
    public List<EclipseModeRow> rows = new List<EclipseModeRow>();
    public bool hasDifficulty = false;
    [Range(0f, 1f)] public float difficulty = .5f;
    public string difficultyText = "Normal";

    [Header("Panel kanan")]
    public Sprite previewArt;
    [TextArea(3, 6)] public string longDescription = "";
    public Sprite[] rewardIcons = new Sprite[3];
    public string[] rewardNames = { "EXP", "Credits", "Weapon\nBlueprint" };

    [Header("Scene misi (kosong = pakai Game Scene Name)")]
    public string sceneName = "";
}

// Layar "Select Game Mode" Project Eclipse.
// Responsif: header/sidebar/panel kanan menempel ke sisi layar, area kartu di tengah melebar mengikuti layar.
// Dibangun langsung di editor; semua gambar diisi sendiri.
public class EclipseGameModeBuilder : MonoBehaviour
{
    [Header("Navigasi scene")]
    public string lobbySceneName = "EclipseLobby";
    public string agentsSceneName = "CharacterSelect";
    public string gameSceneName = "GameScene";
    public bool loadSceneOnStart = true;

    [Header("Opsional: gambar sendiri (kosong = placeholder)")]
    public Font font;
    public Sprite background;
    public Sprite logo, gem, coin, bell, friends, gearTop;
    public Sprite[] sideIcons = new Sprite[5];
    public Sprite recommendIcon, bannerArt, bannerLogo;

    [Header("Teks")]
    public int diamonds = 1200, coins = 15340;
    public string pageTitle = "SELECT GAME MODE";
    public string pageSubtitle = "Choose your mission. Fight for a better tomorrow.";
    [TextArea(2, 3)] public string recommendedText = "Start with Campaign to learn the story\nand get familiar with the game.";
    public string bannerTitle = "CAMPAIGN";
    public string bannerSubtitle = "Chapter 1 : The Lost Signal";
    public string versionText = "v1.0.0     |     FOR A BETTER TOMORROW";
    public string onlineText = "ONLINE     \u2022     1,248 PLAYERS";

    [Header("Daftar mode (5 kartu)")]
    public List<EclipseModeData> modes = new List<EclipseModeData>();
    public int selectedIndex = 0;

    [Serializable] public class RouteEvent : UnityEvent<string> { }
    public RouteEvent onNavigate = new RouteEvent();
    [Serializable] public class IntEvent : UnityEvent<int> { }
    public IntEvent onStartMission = new IntEvent();

    public Color cyan = new Color(.15f, .65f, 1, 1);

    public enum BackdropMode { Stretch, Cover }
    [Header("Latar layar penuh")]
    public BackdropMode backdropMode = BackdropMode.Stretch;

    const string Root = "EclipseGameModeCanvas_v1";
    const int Cards = 5;

    RectTransform frame;
    readonly Dictionary<Transform, Vector2> origin = new Dictionary<Transform, Vector2>();

    enum HA { Left, Center, Right }
    enum VA { Top, Center, Bottom }
    enum Cn { TL, BL, TR, BR, CL }
    HA ha = HA.Left;
    VA va = VA.Top;

    static Sprite sFill, sLine, sGlow, sRing, sDisc, sFade;

    static readonly Color Txt = new Color(.92f, .96f, 1f);
    static readonly Color Dim = new Color(.62f, .74f, .9f);
    static readonly Color PanelFill = new Color(.02f, .06f, .14f, .86f);
    static readonly Color PanelLine = new Color(.24f, .48f, .82f, .95f);
    static readonly Color BrightFill = new Color(.03f, .30f, .88f, .96f);
    static readonly Color BrightLine = new Color(.40f, .78f, 1f, 1f);
    static readonly Color Track = new Color(.07f, .14f, .28f, 1f);
    static readonly Color Gold = new Color(1f, .78f, .25f);

    // kartu: x, lebar, y-atas (acuan 1672x941), bawah semua 716
    static readonly float[] CX = { 250, 505, 721, 933, 1145 };
    static readonly float[] CW = { 242, 200, 197, 198, 180 };
    static readonly float[] CT = { 198, 208, 208, 208, 208 };
    const float CardBottom = 716;

    // ---------------------------------------------------------------- lifecycle

    void Start()
    {
        EnsureDefaults();
        var root = transform.Find(Root);
        if (root == null) Build();
        else
        {
            foreach (var b in root.GetComponentsInChildren<Button>(true))
            {
                string id = b.gameObject.name;
                b.onClick.RemoveAllListeners();
                b.onClick.AddListener(() => Route(id));
            }
        }
        Refresh();
    }

#if UNITY_EDITOR
    void Reset()
    {
        UnityEditor.EditorApplication.delayCall += () => { if (this != null && transform.Find(Root) == null) Build(); };
    }
#endif

    static EclipseModeData M(string title, string desc, string tag, bool gold, params string[] rows)
    {
        var m = new EclipseModeData { title = title, description = desc, tag = tag, tagGold = gold };
        foreach (var r in rows) m.rows.Add(new EclipseModeRow(r));
        return m;
    }

    void EnsureDefaults()
    {
        if (modes == null) modes = new List<EclipseModeData>();
        if (modes.Count > 0) return;

        var a = M("CAMPAIGN", "Follow the story and uncover\nthe truth behind the Eclipse Project.", "POPULAR", false, "Single Player");
        a.hasDifficulty = true; a.difficulty = .5f; a.difficultyText = "Normal";
        a.longDescription = "The Eclipse Project has been activated.\nYour mission is to infiltrate the enemy base,\nfind the missing data, and stop the\nthreat before it's too late.";
        modes.Add(a);

        var b = M("TACTICAL OPERATIONS", "Complete tactical missions\nand eliminate high-value targets.", "", false, "Single / Co-op", "Recommended Lv. 5+");
        b.hasDifficulty = true; b.difficulty = .5f; b.difficultyText = "Normal";
        b.longDescription = "Take on precise tactical missions.\nPlan your approach and eliminate\nhigh-value targets.";
        modes.Add(b);

        var c = M("TEAM BATTLE", "5v5 team combat. Strategy,\nskill and teamwork win the match.", "", false, "Multiplayer", "Players 5 vs 5", "Maps 4+");
        c.longDescription = "Squad up in 5v5 matches.\nStrategy and teamwork decide the winner.";
        modes.Add(c);

        var d = M("SURVIVAL", "Survive endless waves of enemies.\nHow long can you last?", "", false, "Single / Co-op", "Recommended Lv. 10+");
        d.hasDifficulty = true; d.difficulty = .67f; d.difficultyText = "Hard";
        d.longDescription = "Hold your ground against endless\nwaves of enemies. How long can you last?";
        modes.Add(d);

        var e = M("SPECIAL EVENT", "Limited-time event with\nepic rewards.", "LIMITED TIME", true, "Event", "Time Remaining\n3d 12h 45m");
        e.longDescription = "A limited-time event with\nexclusive rewards. Don't miss out!";
        modes.Add(e);
    }

    // ---------------------------------------------------------------- routing

    public void Route(string id)
    {
        onNavigate.Invoke(id);
        if (id.StartsWith("Card"))
        {
            int i;
            if (int.TryParse(id.Substring(4), out i)) Select(i);
        }
        else if (id == "StartMission")
        {
            EnsureDefaults();
            onStartMission.Invoke(selectedIndex);
            if (loadSceneOnStart)
            {
                var m = modes[Mathf.Clamp(selectedIndex, 0, modes.Count - 1)];
                LoadScene(string.IsNullOrEmpty(m.sceneName) ? gameSceneName : m.sceneName);
            }
        }
        else if (id == "TabHome") LoadScene(lobbySceneName);
        else if (id == "TabAgents") LoadScene(agentsSceneName);
        Debug.Log("GameMode: " + id, this);
    }

    void LoadScene(string sceneName)
    {
        if (string.IsNullOrEmpty(sceneName)) return;
        if (Application.CanStreamedLevelBeLoaded(sceneName)) SceneManager.LoadScene(sceneName);
        else Debug.LogError("Scene '" + sceneName + "' belum ada di File > Build Profiles > Scene List.", this);
    }

    public void Select(int i)
    {
        EnsureDefaults();
        int n = Mathf.Min(modes.Count, Cards);
        if (n == 0) return;
        selectedIndex = Mathf.Clamp(i, 0, n - 1);
        Refresh();
    }

    // ---------------------------------------------------------------- refresh

    Transform FindDeep(string n)
    {
        var root = transform.Find(Root);
        if (root == null) return null;
        foreach (var t in root.GetComponentsInChildren<Transform>(true))
            if (t.name == n) return t;
        return null;
    }

    void SetText(string n, string v)
    {
        var t = FindDeep(n);
        if (t == null) return;
        var tx = t.GetComponent<Text>();
        if (tx != null) tx.text = v;
    }

    void SetSprite(string n, Sprite s)
    {
        var t = FindDeep(n);
        if (t == null) return;
        var im = t.GetComponent<Image>();
        if (im != null) { im.sprite = s; im.enabled = s != null; }
    }

    void SetActiveByName(string n, bool on)
    {
        var t = FindDeep(n);
        if (t != null && t.gameObject.activeSelf != on) t.gameObject.SetActive(on);
    }

    public void Refresh()
    {
        if (transform.Find(Root) == null) return;
        EnsureDefaults();
        int count = Mathf.Min(modes.Count, Cards);
        selectedIndex = Mathf.Clamp(selectedIndex, 0, Mathf.Max(0, count - 1));

        SetText("PageTitle", pageTitle);
        SetText("PageSubtitle", pageSubtitle);
        SetText("RecommendedText", recommendedText);
        SetText("BannerTitle", bannerTitle);
        SetText("BannerSub", bannerSubtitle);
        SetText("FooterLeft", versionText);
        SetText("FooterRight", onlineText);
        SetSprite("RecommendIcon", recommendIcon);
        SetSprite("BannerArt", bannerArt);
        SetSprite("BannerLogo", bannerLogo);

        for (int i = 0; i < Cards; i++)
        {
            var card = FindDeep("Card" + i);
            if (card == null) continue;
            card.gameObject.SetActive(i < count);
            if (i >= count) continue;
            var m = modes[i];

            SetText("Card" + i + "Title", m.title);
            SetText("Card" + i + "Desc", m.description);
            SetSprite("Card" + i + "Art", m.cardArt);

            bool hasTag = !string.IsNullOrEmpty(m.tag);
            SetActiveByName("Card" + i + "Tag", hasTag);
            if (hasTag)
            {
                SetText("Card" + i + "TagText", m.tag);
                var tag = FindDeep("Card" + i + "Tag");
                var tf = tag.Find("Fill").GetComponent<Image>();
                var tl = tag.Find("Outline").GetComponent<Image>();
                tf.color = m.tagGold ? new Color(.3f, .17f, .02f, .95f) : new Color(.03f, .22f, .7f, .96f);
                tl.color = m.tagGold ? new Color(.95f, .7f, .2f, 1f) : BrightLine;
                FindDeep("Card" + i + "TagText").GetComponent<Text>().color = m.tagGold ? Gold : Color.white;
            }

            int ni = Mathf.Min(m.rows != null ? m.rows.Count : 0, m.hasDifficulty ? 2 : 3);
            for (int r = 0; r < 3; r++)
            {
                bool isInfo = r < ni;
                bool isDiff = m.hasDifficulty && r == ni;
                string p = "Card" + i + "Row" + r;
                SetActiveByName(p + "Icon", isInfo);
                SetActiveByName(p + "Text", isInfo || isDiff);
                SetActiveByName(p + "Track", isDiff);
                SetActiveByName(p + "Fill", isDiff);
                SetActiveByName(p + "Sep0", isDiff);
                SetActiveByName(p + "Sep1", isDiff);
                SetActiveByName(p + "Value", isDiff);
                if (isInfo)
                {
                    SetText(p + "Text", m.rows[r].text);
                    SetSprite(p + "Icon", m.rows[r].icon);
                }
                else if (isDiff)
                {
                    SetText(p + "Text", "Difficulty");
                    SetText(p + "Value", m.difficultyText);
                    var f = FindDeep(p + "Fill") as RectTransform;
                    if (f != null) f.sizeDelta = new Vector2(70f * Mathf.Clamp01(m.difficulty), f.sizeDelta.y);
                }
            }

            bool sel = i == selectedIndex;
            var o = card.Find("Outline");
            if (o != null) o.GetComponent<Image>().color = sel ? BrightLine : PanelLine;
            var g = card.Find("Glow");
            if (g != null) g.GetComponent<Image>().enabled = sel;
        }

        var cur = modes[selectedIndex];
        SetText("ModeTitle", cur.title);
        SetSprite("ModePreview", cur.previewArt);
        SetText("ModeDesc", cur.longDescription);
        for (int k = 0; k < 3; k++)
        {
            SetSprite("Reward" + k + "Icon", cur.rewardIcons != null && k < cur.rewardIcons.Length ? cur.rewardIcons[k] : null);
            SetText("Reward" + k + "Label", cur.rewardNames != null && k < cur.rewardNames.Length ? cur.rewardNames[k] : "");
        }
    }

    // ---------------------------------------------------------------- helpers (anchor mutlak, level frame)

    RectTransform R(Transform p, string n, float x, float y, float w, float h)
    {
        var go = new GameObject(n, typeof(RectTransform));
        var r = go.GetComponent<RectTransform>();
        r.SetParent(p, false);
        Vector2 o;
        origin.TryGetValue(p, out o);
        r.pivot = new Vector2(0, 1);
        if (p == frame)
        {
            float ax = ha == HA.Left ? 0 : (ha == HA.Right ? 1672 : 836);
            float ay = va == VA.Top ? 0 : (va == VA.Bottom ? 941 : 470.5f);
            r.anchorMin = r.anchorMax = new Vector2(ha == HA.Left ? 0 : (ha == HA.Right ? 1 : .5f),
                                                    va == VA.Top ? 1 : (va == VA.Bottom ? 0 : .5f));
            r.anchoredPosition = new Vector2(x - ax, -(y - ay));
        }
        else
        {
            r.anchorMin = r.anchorMax = new Vector2(0, 1);
            r.anchoredPosition = new Vector2(x - o.x, -(y - o.y));
        }
        r.sizeDelta = new Vector2(w, h);
        origin[r] = new Vector2(x, y);
        return r;
    }

    Image Img(Transform p, string n, float x, float y, float w, float h, Sprite s, Color c, bool sliced = false, bool ray = false)
    {
        var i = R(p, n, x, y, w, h).gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = c;
        i.raycastTarget = ray;
        if (s != null)
        {
            if (sliced) i.type = Image.Type.Sliced;
            else i.preserveAspect = true;
        }
        return i;
    }

    Image S(Transform p, string n, float x, float y, float w, float h, Color c) { return Img(p, n, x, y, w, h, null, c); }

    Text Style(Text t, string s, int size, bool bold, TextAnchor a, bool italic, Color? col)
    {
        t.font = font;
        t.text = s;
        t.fontSize = size;
        t.fontStyle = bold ? (italic ? FontStyle.BoldAndItalic : FontStyle.Bold) : (italic ? FontStyle.Italic : FontStyle.Normal);
        t.color = col ?? Txt;
        t.alignment = a;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    Text T(Transform p, string n, string s, float x, float cy, float w, int size, bool bold = false,
           TextAnchor a = TextAnchor.MiddleLeft, bool italic = false, Color? col = null)
    {
        float h = size * 1.6f;
        var t = R(p, n, x, cy - h / 2f, w, h).gameObject.AddComponent<Text>();
        return Style(t, s, size, bold, a, italic, col);
    }

    Image Icon(Transform p, string n, Sprite sprite, float x, float y, float w, float h)
    {
        var i = Img(p, n, x, y, w, h, sprite, Color.white);
        i.preserveAspect = true;
        i.gameObject.AddComponent<EclipseIconSlot>();
        return i;
    }

    RectTransform Panel(Transform p, string n, float x, float y, float w, float h, Color fill, Color line, float glow = 0)
    {
        var r = R(p, n, x, y, w, h);
        if (glow > 0) Img(r, "Glow", x - 20, y - 20, w + 40, h + 40, GlowSprite(), new Color(.1f, .5f, 1f, glow), true);
        Img(r, "Fill", x, y, w, h, FillSprite(), fill, true);
        Img(r, "Outline", x, y, w, h, LineSprite(), line, true);
        return r;
    }

    // ---------------------------------------------------------------- helpers (anchor relatif: stretch / sudut)

    RectTransform NewRT(Transform p, string n)
    {
        var rt = new GameObject(n, typeof(RectTransform)).GetComponent<RectTransform>();
        rt.SetParent(p, false);
        return rt;
    }

    RectTransform Fr(Transform p, string n, Vector2 amin, Vector2 amax, Vector2 omin, Vector2 omax)
    {
        var rt = NewRT(p, n);
        rt.anchorMin = amin; rt.anchorMax = amax;
        rt.offsetMin = omin; rt.offsetMax = omax;
        return rt;
    }

    RectTransform Corner(Transform p, string n, Cn c, float dx, float dy, float w, float h)
    {
        var rt = NewRT(p, n);
        float ax = (c == Cn.TR || c == Cn.BR) ? 1 : 0;
        float ay = (c == Cn.TL || c == Cn.TR) ? 1 : (c == Cn.CL ? .5f : 0);
        rt.anchorMin = rt.anchorMax = new Vector2(ax, ay);
        rt.pivot = new Vector2(ax, ay);
        rt.anchoredPosition = new Vector2(ax == 1 ? -dx : dx, ay == 1 ? -dy : dy);
        rt.sizeDelta = new Vector2(w, h);
        return rt;
    }

    Image FillImg(Transform p, string n, Sprite s, Color c, bool sliced, float expand = 0)
    {
        var rt = Fr(p, n, Vector2.zero, Vector2.one, new Vector2(-expand, -expand), new Vector2(expand, expand));
        var i = rt.gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = c;
        i.raycastTarget = false;
        if (s != null && sliced) i.type = Image.Type.Sliced;
        return i;
    }

    void SPanel(RectTransform rt, Color fill, Color line, float glow = 0)
    {
        if (glow > 0) FillImg(rt, "Glow", GlowSprite(), new Color(.1f, .5f, 1f, glow), true, 20);
        FillImg(rt, "Fill", FillSprite(), fill, true);
        FillImg(rt, "Outline", LineSprite(), line, true);
    }

    RectTransform CPanel(Transform p, string n, Cn c, float dx, float dy, float w, float h, Color fill, Color line, float glow = 0)
    {
        var rt = Corner(p, n, c, dx, dy, w, h);
        SPanel(rt, fill, line, glow);
        return rt;
    }

    Image CImg(Transform p, string n, Cn c, float dx, float dy, float w, float h, Sprite s, Color col)
    {
        var rt = Corner(p, n, c, dx, dy, w, h);
        var i = rt.gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = col;
        i.raycastTarget = false;
        i.preserveAspect = true;
        return i;
    }

    Image CIcon(Transform p, string n, Cn c, float dx, float dy, float w, float h)
    {
        var i = CImg(p, n, c, dx, dy, w, h, null, Color.white);
        i.gameObject.AddComponent<EclipseIconSlot>();
        return i;
    }

    Text CText(Transform p, string n, string s, Cn c, float dx, float dy, float w, float h, int size,
               bool bold = false, TextAnchor a = TextAnchor.MiddleLeft, bool italic = false, Color? col = null)
    {
        var rt = Corner(p, n, c, dx, dy, w, h);
        return Style(rt.gameObject.AddComponent<Text>(), s, size, bold, a, italic, col);
    }

    void Click(RectTransform root)
    {
        Graphic target = null;
        var outline = root.Find("Outline");
        if (outline != null) target = outline.GetComponent<Graphic>();
        if (target == null)
        {
            var ic = root.Find("Icon");
            if (ic != null) target = ic.GetComponent<Graphic>();
        }
        var fill = root.Find("Fill");
        if (fill != null) fill.GetComponent<Graphic>().raycastTarget = true;
        else
        {
            var hit = FillImg(root, "Hit", null, new Color(0, 0, 0, 0), false);
            hit.raycastTarget = true;
            if (target == null) target = root.GetComponentInChildren<Text>();
            if (target == null) target = hit;
        }
        var b = root.gameObject.AddComponent<Button>();
        b.targetGraphic = target;
        var c = b.colors;
        c.normalColor = new Color(.88f, .92f, 1f, 1f);
        c.highlightedColor = Color.white;
        c.pressedColor = new Color(.6f, .78f, 1f, 1f);
        c.selectedColor = Color.white;
        c.fadeDuration = .1f;
        b.colors = c;
        string id = root.name;
        b.onClick.AddListener(() => Route(id));
    }

    void BackdropStretch()
    {
        var parent = frame.parent;
        var cont = new GameObject("BackdropRoot", typeof(RectTransform), typeof(RectMask2D));
        cont.transform.SetParent(parent, false);
        cont.transform.SetAsFirstSibling();
        var cr = cont.GetComponent<RectTransform>();
        cr.anchorMin = Vector2.zero; cr.anchorMax = Vector2.one; cr.offsetMin = cr.offsetMax = Vector2.zero;

        var solid = new GameObject("BackdropSolid", typeof(RectTransform), typeof(Image));
        solid.transform.SetParent(cont.transform, false);
        var sr = solid.GetComponent<RectTransform>();
        sr.anchorMin = Vector2.zero; sr.anchorMax = Vector2.one; sr.offsetMin = sr.offsetMax = Vector2.zero;
        var si = solid.GetComponent<Image>();
        si.color = new Color(.015f, .048f, .105f);
        si.raycastTarget = false;

        var bg = new GameObject("Backdrop", typeof(RectTransform), typeof(Image), typeof(EclipseIconSlot));
        bg.transform.SetParent(cont.transform, false);
        var img = bg.GetComponent<Image>();
        img.sprite = background;
        img.color = Color.white;
        img.raycastTarget = false;
        img.preserveAspect = false;
        var br = bg.GetComponent<RectTransform>();
        if (backdropMode == BackdropMode.Cover)
        {
            var fit = bg.AddComponent<AspectRatioFitter>();
            fit.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            fit.aspectRatio = 1672f / 941f;
        }
        else
        {
            br.anchorMin = Vector2.zero; br.anchorMax = Vector2.one; br.offsetMin = br.offsetMax = Vector2.zero;
        }
    }

    void HLine(string n, float y, float h, float margin, Color c, bool bottom)
    {
        var go = new GameObject(n, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(frame, false);
        var r = go.GetComponent<RectTransform>();
        float ay = bottom ? 0 : 1;
        r.anchorMin = new Vector2(0, ay);
        r.anchorMax = new Vector2(1, ay);
        r.pivot = new Vector2(.5f, ay);
        if (bottom) { r.offsetMin = new Vector2(margin, 941 - (y + h)); r.offsetMax = new Vector2(-margin, 941 - y); }
        else { r.offsetMin = new Vector2(margin, -(y + h)); r.offsetMax = new Vector2(-margin, -y); }
        var im = go.GetComponent<Image>();
        im.color = c;
        im.raycastTarget = false;
    }

    // ---------------------------------------------------------------- sprite generator (PNG nyata di editor)

    static float Sd(float x, float y, float x0, float y0, float x1, float y1, float c)
    {
        float d = Mathf.Min(Mathf.Min(x - x0, x1 - x), Mathf.Min(y - y0, y1 - y));
        float tl = ((x - x0) + (y1 - y) - c) * 0.70710678f;
        float br = ((x1 - x) + (y - y0) - c) * 0.70710678f;
        return Mathf.Min(d, Mathf.Min(tl, br));
    }

    static Sprite Make(string name, int w, int h, int border, Func<float, float, Color> px)
    {
#if UNITY_EDITOR
        const string dir = "Assets/EclipseLobby/Generated";
        string path = dir + "/" + name + ".png";
        var existing = UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (existing != null) return existing;
#endif
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.name = name;
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        var cols = new Color32[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                cols[y * w + x] = px(x + .5f, y + .5f);
        t.SetPixels32(cols);
        t.Apply();
#if UNITY_EDITOR
        System.IO.Directory.CreateDirectory(dir);
        System.IO.File.WriteAllBytes(path, t.EncodeToPNG());
        UnityEngine.Object.DestroyImmediate(t);
        UnityEditor.AssetDatabase.ImportAsset(path, UnityEditor.ImportAssetOptions.ForceSynchronousImport);
        var ti = (UnityEditor.TextureImporter)UnityEditor.AssetImporter.GetAtPath(path);
        ti.textureType = UnityEditor.TextureImporterType.Sprite;
        ti.spriteImportMode = UnityEditor.SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 100;
        ti.spriteBorder = new Vector4(border, border, border, border);
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.filterMode = FilterMode.Bilinear;
        ti.textureCompression = UnityEditor.TextureImporterCompression.Uncompressed;
        ti.SaveAndReimport();
        return UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
#else
        var s = Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect,
                              new Vector4(border, border, border, border));
        s.name = name;
        return s;
#endif
    }

    static Sprite FillSprite()
    {
        if (sFill == null)
            sFill = Make("EclipseFill", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f);
                float g = Mathf.Lerp(.72f, 1f, y / 64f);
                return new Color(g, g, g, a);
            });
        return sFill;
    }

    static Sprite LineSprite()
    {
        if (sLine == null)
            sLine = Make("EclipseLine", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f) * Mathf.Clamp01(2.1f - d);
                return new Color(1, 1, 1, a);
            });
        return sLine;
    }

    static Sprite GlowSprite()
    {
        if (sGlow == null)
            sGlow = Make("EclipseGlow", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 20, 20, 44, 44, 12);
                float a = d >= 0 ? 1f : Mathf.Pow(Mathf.Clamp01(1f + d / 20f), 2.2f);
                return new Color(1, 1, 1, a);
            });
        return sGlow;
    }

    static Sprite RingSprite()
    {
        if (sRing == null)
            sRing = Make("EclipseRing", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(1.6f - Mathf.Abs(r - 13.5f) + .5f));
            });
        return sRing;
    }

    static Sprite DiscSprite()
    {
        if (sDisc == null)
            sDisc = Make("EclipseDisc", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(15f - r));
            });
        return sDisc;
    }

    // gradasi vertikal: gelap penuh di bawah, transparan di atas
    static Sprite FadeSprite()
    {
        if (sFade == null)
            sFade = Make("EclipseFade", 4, 64, 0, (x, y) => new Color(1, 1, 1, Mathf.Clamp01(1f - y / 64f)));
        return sFade;
    }

    // ---------------------------------------------------------------- build

    [ContextMenu("Build Game Mode")]
    public void Build()
    {
        EnsureDefaults();
        Transform old;
        while ((old = transform.Find(Root)) != null)
        {
            old.gameObject.SetActive(false);
            old.SetParent(null);
            if (Application.isPlaying) Destroy(old.gameObject);
            else DestroyImmediate(old.gameObject);
        }
        origin.Clear();

        if (font == null)
        {
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        var go = new GameObject(Root, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.transform.SetParent(transform, false);
        go.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scale = go.GetComponent<CanvasScaler>();
        scale.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scale.referenceResolution = new Vector2(1672, 941);
        scale.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;

        frame = new GameObject("ReferenceFrame", typeof(RectTransform)).GetComponent<RectTransform>();
        frame.SetParent(go.transform, false);
        frame.anchorMin = Vector2.zero;
        frame.anchorMax = Vector2.one;
        frame.offsetMin = frame.offsetMax = Vector2.zero;
        frame.gameObject.AddComponent<EclipseSafeArea>();
        origin[frame] = Vector2.zero;

        BackdropStretch();
        Header();
        Sidebar();
        MainArea();
        InfoPanel();
        Footer();

#if UNITY_2023_1_OR_NEWER
        bool noES = UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null;
#else
        bool noES = UnityEngine.Object.FindObjectOfType<EventSystem>() == null;
#endif
        if (noES)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        Refresh();
    }

    // ---------------------------------------------------------------- header

    void Header()
    {
        ha = HA.Left; va = VA.Top;
        Icon(frame, "Logo", logo, 30, 8, 90, 80);

        Panel(frame, "TabStrip", 320, 22, 790, 46, PanelFill, PanelLine);
        Tab("TabHome", "HOME", 410, 110, false);
        Tab("TabPlay", "PLAY", 536, 140, true);
        Tab("TabAgents", "AGENTS", 662, 110, false);
        Tab("TabArmory", "ARMORY", 786, 110, false);
        Tab("TabInventory", "INVENTORY", 910, 120, false);
        Tab("TabStore", "STORE", 1033, 110, false);

        ha = HA.Right;
        Wallet("Diamonds", 1133, 150, gem, diamonds.ToString("N0"));
        Wallet("Coins", 1296, 152, coin, coins.ToString("N0"));

        var b = R(frame, "Notifications", 1478, 22, 44, 46);
        Icon(b, "Icon", bell, 1480, 24, 38, 42);
        Img(b, "AlertBadge", 1503, 18, 18, 18, DiscSprite(), new Color(.86f, .08f, .12f));
        T(b, "Alert", "!", 1503, 27, 18, 11, true, TextAnchor.MiddleCenter);
        Click(b);

        var f = R(frame, "Friends", 1544, 22, 50, 46);
        Icon(f, "Icon", friends, 1546, 26, 46, 40);
        Click(f);

        var s = R(frame, "SettingsTop", 1606, 22, 46, 46);
        Icon(s, "Icon", gearTop, 1608, 24, 42, 42);
        Click(s);

        ha = HA.Left;
        HLine("HeaderRule", 90, 1, 0, new Color(.15f, .36f, .65f, .55f), false);
    }

    void Tab(string id, string label, float cx, float w, bool active)
    {
        RectTransform r;
        if (active)
        {
            r = Panel(frame, id, cx - w / 2f, 22, w, 46, BrightFill, BrightLine, .6f);
        }
        else
        {
            r = R(frame, id, cx - w / 2f, 22, w, 46);
        }
        T(r, id + "Label", label, cx - w / 2f, 45, w, 17, active, TextAnchor.MiddleCenter, false, active ? Color.white : Txt);
        Click(r);
    }

    void Wallet(string id, float x, float w, Sprite icon, string value)
    {
        var p = Panel(frame, id, x, 20, w, 44, new Color(.01f, .04f, .10f, .85f), new Color(.2f, .42f, .74f, .9f));
        Icon(p, "Icon", icon, x + 8, 21, 34, 42);
        T(p, "Balance", value, x + 50, 42, w - 90, 20, true);
        S(p, "PlusDivider", x + w - 38, 25, 1, 34, new Color(.2f, .4f, .7f, .5f));
        T(p, "Plus", "+", x + w - 38, 42, 38, 30, false, TextAnchor.MiddleCenter);
        Click(p);
    }

    // ---------------------------------------------------------------- sidebar

    void Sidebar()
    {
        // latar + garis sisi: meregang vertikal
        var bg = Fr(frame, "SidebarBg", new Vector2(0, 0), new Vector2(0, 1), new Vector2(0, 71), new Vector2(226, -100));
        var bgi = bg.gameObject.AddComponent<Image>();
        bgi.color = new Color(.01f, .035f, .09f, .75f);
        bgi.raycastTarget = false;
        var ln = Fr(frame, "SidebarLine", new Vector2(0, 0), new Vector2(0, 1), new Vector2(225, 71), new Vector2(226, -100));
        var lni = ln.gameObject.AddComponent<Image>();
        lni.color = new Color(.15f, .36f, .65f, .6f);
        lni.raycastTarget = false;

        ha = HA.Left; va = VA.Top;
        string[] ids = { "SideGameMode", "SideCampaign", "SideMultiplayer", "SideCoop", "SideTraining" };
        string[] names = { "GAME MODE", "CAMPAIGN", "MULTIPLAYER", "CO-OP", "TRAINING" };
        float[] cy = { 154, 228, 301, 374, 447 };
        for (int i = 0; i < 5; i++)
        {
            RectTransform r;
            if (i == 0)
            {
                r = Panel(frame, ids[i], 0, cy[i] - 34, 228, 68, new Color(.03f, .28f, .82f, .96f), BrightLine);
            }
            else
            {
                r = R(frame, ids[i], 0, cy[i] - 34, 226, 68);
            }
            Icon(r, "Icon", sideIcons != null && i < sideIcons.Length ? sideIcons[i] : null, 34, cy[i] - 20, 40, 40);
            T(r, ids[i] + "Label", names[i], 88, cy[i], 130, 18, true);
            Click(r);
            if (i < 4) S(frame, "SideSep" + i, 6, cy[i] + 37, 214, 1, new Color(.15f, .3f, .5f, .7f));
        }
    }

    // ---------------------------------------------------------------- area tengah (meregang)

    void MainArea()
    {
        // area antara sidebar (x=250) dan panel kanan (x=1324), y=116..849; melebar & memanjang mengikuti layar
        const float AW = 1074f, AH = 733f, AX = 250f, AY = 116f;
        var area = Fr(frame, "MainArea", Vector2.zero, Vector2.one, new Vector2(250, 92), new Vector2(-348, -116));

        CText(area, "PageTitle", "", Cn.TL, 7, 6, 700, 44, 32, true, TextAnchor.MiddleLeft, true);
        CText(area, "PageSubtitle", "", Cn.TL, 7, 44, 700, 30, 19, false, TextAnchor.MiddleLeft, false, Dim);

        for (int i = 0; i < Cards; i++)
        {
            float xf0 = (CX[i] - AX) / AW, xf1 = (CX[i] + CW[i] - AX) / AW;
            float yTop = (CT[i] - AY) / AH, yBot = (CardBottom - AY) / AH;
            var card = Fr(area, "Card" + i, new Vector2(xf0, 1 - yBot), new Vector2(xf1, 1 - yTop), Vector2.zero, Vector2.zero);
            SPanel(card, new Color(.02f, .08f, .22f, .92f), PanelLine, .7f);
            BuildCard(card, i);
            Click(card);
        }

        // banner rekomendasi di bawah
        var banner = Fr(area, "RecommendedBanner", Vector2.zero, new Vector2(1, 1 - (745 - AY) / AH), new Vector2(3, 0), new Vector2(-5, 0));
        SPanel(banner, new Color(.02f, .07f, .18f, .92f), PanelLine);

        var left = Fr(banner, "BannerLeft", new Vector2(0, 0), new Vector2(0, 1), new Vector2(0, 0), new Vector2(322, 0));
        var ri = CImg(left, "RecommendIcon", Cn.CL, 18, 0, 44, 44, null, Color.white);
        ri.gameObject.AddComponent<EclipseIconSlot>();
        CText(left, "RecommendedTitle", "RECOMMENDED", Cn.CL, 78, 24, 220, 22, 15, true, TextAnchor.MiddleLeft, false, new Color(.45f, .8f, 1f));
        CText(left, "RecommendedText", "", Cn.CL, 78, -14, 240, 40, 14, false, TextAnchor.MiddleLeft, false, new Color(.85f, .92f, 1f));

        var artRoot = Fr(banner, "BannerArtRoot", Vector2.zero, Vector2.one, new Vector2(322, 2), new Vector2(-2, -2));
        var bart = FillImg(artRoot, "BannerArt", null, Color.white, false);
        bart.gameObject.AddComponent<EclipseIconSlot>();
        bart.preserveAspect = false;
        CImg(artRoot, "BannerLogo", Cn.CL, 14, 0, 48, 48, null, Color.white).gameObject.AddComponent<EclipseIconSlot>();
        CText(artRoot, "BannerTitle", "", Cn.CL, 76, 12, 400, 28, 19, true);
        CText(artRoot, "BannerSub", "", Cn.CL, 76, -14, 400, 22, 14, false, TextAnchor.MiddleLeft, false, new Color(.8f, .9f, 1f));
        // gambar kecil agar urutan: art di belakang teks
        bart.transform.SetAsFirstSibling();
        Click(banner);
    }

    // isi satu kartu; posisi isi relatif terhadap sisi bawah kartu (acuan bawah = 716)
    void BuildCard(RectTransform card, int i)
    {
        bool big = i == 0;

        // gambar kartu (di bawah garis tepi) + gradasi gelap di bawah
        var art = FillImg(card, "Card" + i + "Art", null, Color.white, false);
        art.gameObject.AddComponent<EclipseIconSlot>();
        art.preserveAspect = false;
        var fadeRt = Fr(card, "Card" + i + "Fade", new Vector2(0, 0), new Vector2(1, 0), new Vector2(2, 2), new Vector2(-2, 360));
        var fade = fadeRt.gameObject.AddComponent<Image>();
        fade.sprite = FadeSprite();
        fade.color = new Color(.005f, .02f, .07f, .96f);
        fade.raycastTarget = false;
        var outline = card.Find("Outline");
        art.transform.SetSiblingIndex(outline.GetSiblingIndex());
        fadeRt.SetSiblingIndex(outline.GetSiblingIndex());

        // tag
        var tag = CPanel(card, "Card" + i + "Tag", Cn.TL, 15, 15, big ? 88 : 104, 24, new Color(.03f, .22f, .7f, .96f), BrightLine);
        var tt = CText(tag, "Card" + i + "TagText", "", Cn.TL, 0, 0, big ? 88 : 104, 24, 12, true, TextAnchor.MiddleCenter);

        float dx = big ? 16 : 12;
        float titleCy = big ? 533 : 531;
        float descCy = big ? 574 : 570;
        CText(card, "Card" + i + "Title", "", Cn.BL, dx, CardBottom - (titleCy + 20), 300, 40, big ? 27 : 20, true);
        CText(card, "Card" + i + "Desc", "", Cn.BL, dx, CardBottom - (descCy + 20), 300, 40, 14, false, TextAnchor.MiddleLeft, false, new Color(.85f, .92f, 1f));

        float start = big ? 624 : 611;
        float step = big ? 29 : 27;
        for (int r = 0; r < 3; r++)
        {
            float cy = start + r * step;
            float dyb = CardBottom - (cy + 11);
            string p = "Card" + i + "Row" + r;
            CIcon(card, p + "Icon", Cn.BL, dx + 2, dyb, 20, 22);
            CText(card, p + "Text", "", Cn.BL, dx + 28, dyb - 4, 220, 30, 13);

            // bar difficulty: track + isi + 2 pemisah
            float bx = dx + 66;
            float dyt = CardBottom - (cy + 3);
            var tr = CImg(card, p + "Track", Cn.BL, bx, dyt, 70, 6, null, Track);
            var fl = CImg(card, p + "Fill", Cn.BL, bx, dyt, 35, 6, null, cyan);
            CImg(card, p + "Sep0", Cn.BL, bx + 23, dyt, 1.5f, 6, null, new Color(.01f, .03f, .08f, 1));
            CImg(card, p + "Sep1", Cn.BL, bx + 46, dyt, 1.5f, 6, null, new Color(.01f, .03f, .08f, 1));
            tr.preserveAspect = false; fl.preserveAspect = false;
            CText(card, p + "Value", "", Cn.BR, 12, dyb - 4, 80, 30, 12, false, TextAnchor.MiddleRight, false, new Color(.85f, .92f, 1f));
        }

        CText(card, "Card" + i + "Chevron", ">", Cn.BR, 14, 6, 24, 30, 24, false, TextAnchor.MiddleCenter, false, new Color(.8f, .9f, 1f));
    }

    // ---------------------------------------------------------------- panel kanan

    void InfoPanel()
    {
        ha = HA.Right; va = VA.Top;
        var p = Fr(frame, "InfoPanel", new Vector2(1, 0), new Vector2(1, 1), new Vector2(-324, 86), new Vector2(0, -116));
        SPanel(p, new Color(.015f, .05f, .12f, .92f), PanelLine);
        foreach (var g in p.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        var head = CPanel(p, "ModeHead", Cn.TL, 21, 19, 284, 50, new Color(.01f, .04f, .1f, .9f), new Color(.15f, .3f, .55f, .8f));
        CImg(head, "ModeAccent", Cn.TL, 0, 8, 3, 34, null, cyan).preserveAspect = false;
        CText(head, "ModeTitle", "", Cn.TL, 18, 0, 250, 50, 22, true);
        foreach (var g in head.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        var prev = CImg(p, "ModePreview", Cn.TL, 22, 74, 282, 215, null, Color.white);
        prev.preserveAspect = false;
        prev.gameObject.AddComponent<EclipseIconSlot>();
        var pl = CImg(p, "ModePreviewFrame", Cn.TL, 22, 74, 282, 215, LineSprite(), new Color(.3f, .55f, .9f, .9f));
        pl.type = Image.Type.Sliced; pl.preserveAspect = false;

        var desc = CText(p, "ModeDesc", "", Cn.TL, 23, 306, 285, 100, 15, false, TextAnchor.UpperLeft, false, new Color(.8f, .88f, .98f));
        desc.horizontalOverflow = HorizontalWrapMode.Wrap;
        desc.lineSpacing = 1.25f;

        CImg(p, "Divider", Cn.TL, 22, 445, 284, 1, null, new Color(.15f, .3f, .5f, .8f)).preserveAspect = false;
        CText(p, "RewardsHeading", "REWARDS", Cn.TL, 23, 453, 200, 26, 17, true);

        for (int k = 0; k < 3; k++)
        {
            var rc = CPanel(p, "RewardCard" + k, Cn.TL, 22 + k * 98, 491, 75, 78, new Color(.02f, .08f, .22f, .9f), PanelLine);
            CIcon(rc, "Reward" + k + "Icon", Cn.TL, 17, 6, 41, 41);
            CText(rc, "Reward" + k + "Label", "", Cn.TL, 0, 46, 75, 30, 12, false, TextAnchor.MiddleCenter);
            foreach (var g in rc.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;
        }

        var start = CPanel(p, "StartMission", Cn.BL, 22, 51, 282, 62, BrightFill, BrightLine, .7f);
        FillImg(start, "InnerFrame", LineSprite(), new Color(.35f, .75f, 1f, .45f), true, -5);
        CText(start, "StartLabel", "START MISSION", Cn.TL, 0, 0, 250, 62, 22, true, TextAnchor.MiddleCenter, true);
        CText(start, "StartChevrons", "\u00BB", Cn.TR, 16, 0, 40, 62, 28, true, TextAnchor.MiddleCenter, true, new Color(.55f, .85f, 1f));
        Click(start);
    }

    // ---------------------------------------------------------------- footer

    void Footer()
    {
        ha = HA.Left; va = VA.Bottom;
        HLine("FooterRule", 870, 1, 0, new Color(.15f, .36f, .65f, .55f), true);
        T(frame, "FooterLeft", "", 36, 905, 600, 11, false, TextAnchor.MiddleLeft, false, Dim);
        ha = HA.Right;
        T(frame, "FooterRight", "", 1035, 905, 600, 11, false, TextAnchor.MiddleRight, false, Dim);
    }
}
