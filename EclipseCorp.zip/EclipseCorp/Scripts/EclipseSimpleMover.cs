using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

// Contoh gerak sederhana untuk menguji joystick (Input System baru).
// Membaca "<Gamepad>/leftStick" (joystick layar) dan WASD (untuk tes di editor), lalu menggerakkan target
// relatif terhadap kamera. Ganti dengan controller karaktermu nanti.
public class EclipseSimpleMover : MonoBehaviour
{
    [Tooltip("Kosong = pakai karakter yang dimunculkan Spawner.")]
    public Transform target;
    public EclipseAgentSpawner spawner;
    public Transform cameraTransform;
    public float speed = 4f;
    public float turnSpeed = 12f;

#if ENABLE_INPUT_SYSTEM
    InputAction move;

    void OnEnable()
    {
        move = new InputAction("Move", InputActionType.Value);
        move.AddBinding("<Gamepad>/leftStick");
        move.AddCompositeBinding("2DVector")
            .With("Up", "<Keyboard>/w").With("Down", "<Keyboard>/s")
            .With("Left", "<Keyboard>/a").With("Right", "<Keyboard>/d");
        move.Enable();
    }

    void OnDisable()
    {
        if (move != null) { move.Disable(); move.Dispose(); move = null; }
    }

    void Update()
    {
        var t = target != null ? target : (spawner != null && spawner.Spawned != null ? spawner.Spawned.transform : null);
        if (t == null || move == null) return;
        if (cameraTransform == null && Camera.main != null) cameraTransform = Camera.main.transform;

        Vector2 v = move.ReadValue<Vector2>();
        if (v.sqrMagnitude < 0.0004f) return;

        Vector3 fwd = cameraTransform != null ? Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized : Vector3.forward;
        Vector3 right = cameraTransform != null ? Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized : Vector3.right;
        Vector3 dir = fwd * v.y + right * v.x;
        t.position += dir * speed * Time.deltaTime;
        if (dir.sqrMagnitude > 0.0001f)
            t.rotation = Quaternion.Slerp(t.rotation, Quaternion.LookRotation(dir), turnSpeed * Time.deltaTime);
    }
#else
    void Start() { Debug.LogWarning("EclipseSimpleMover membutuhkan Input System (baru)."); }
#endif
}
