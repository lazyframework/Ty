using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Rendering;

// Pasang di GameScene: memunculkan karakter yang dipilih di layar Select Character.
// Membaca nomor agen dari PlayerPrefs, lalu mengambil Model Prefab dari Agent Database.
// Kalau modelnya belum ada, muncul kapsul berwarna sebagai penanda (lengkap dengan collider).
public class EclipseAgentSpawner : MonoBehaviour
{
    public EclipseAgentDatabase database;
    [Tooltip("Harus sama dengan Selected Agent Prefs Key di layar Select Character.")]
    public string selectedAgentPrefsKey = "EclipseSelectedAgent";
    [Tooltip("Titik muncul. Kosong = posisi objek ini.")]
    public Transform spawnPoint;
    public bool spawnOnStart = true;
    public bool placeholderWhenNoModel = true;
    [Tooltip("Opsional: isi bar HP/Armor di HUD dari stat agen.")]
    public EclipseGameHudBuilder hud;

    [System.Serializable] public class SpawnEvent : UnityEvent<GameObject> { }
    public SpawnEvent onSpawned = new SpawnEvent();

    public GameObject Spawned { get; private set; }
    public EclipseAgentData Agent { get; private set; }
    public int Index { get; private set; }

    void Start()
    {
        if (spawnOnStart) Spawn();
    }

    public GameObject Spawn()
    {
        if (Spawned != null) Destroy(Spawned);

        Index = PlayerPrefs.GetInt(selectedAgentPrefsKey, 0);
        Agent = database != null ? database.Get(Index) : null;
        if (database != null && database.Count > 0) Index = Mathf.Clamp(Index, 0, database.Count - 1);

        Vector3 pos = spawnPoint != null ? spawnPoint.position : transform.position;
        Quaternion rot = spawnPoint != null ? spawnPoint.rotation : transform.rotation;

        if (Agent != null && Agent.modelPrefab != null)
            Spawned = Instantiate(Agent.modelPrefab, pos, rot);
        else if (placeholderWhenNoModel)
            Spawned = MakePlaceholder(pos, rot, Index);

        if (Spawned != null)
        {
            Spawned.name = Agent != null ? Agent.agentName : "Agent";
            onSpawned.Invoke(Spawned);
        }

        if (hud != null && Agent != null)
        {
            hud.SetHp(Agent.hp, Agent.hp);
            hud.SetArmor(Agent.armor, Agent.armor);
        }
        return Spawned;
    }

    static GameObject MakePlaceholder(Vector3 pos, Quaternion rot, int index)
    {
        var cap = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        cap.transform.SetPositionAndRotation(pos + Vector3.up * 1f, rot);
        Shader sh = GraphicsSettings.currentRenderPipeline != null
            ? Shader.Find("Universal Render Pipeline/Lit")
            : Shader.Find("Standard");
        if (sh == null) sh = Shader.Find("Sprites/Default");
        if (sh != null)
        {
            var m = new Material(sh);
            m.color = Color.HSVToRGB(Mathf.Repeat(.58f + index * .17f, 1f), .55f, .9f);
            cap.GetComponent<Renderer>().material = m;
        }
        return cap;
    }
}
