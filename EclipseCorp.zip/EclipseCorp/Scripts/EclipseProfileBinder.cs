using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Menampilkan data profil realtime (EclipsePlayerData) ke UI.
// Dipasang otomatis oleh EclipsePlayerData ke objek Lobby / HUD / Select Character / Game Mode.
// - Lobby:  nama, level, EXP + bar, rank, diamonds, coins
// - HUD:    nama, level, EXP, rank, diamonds, coins (lewat field milik HUD supaya tidak tertimpa Refresh)
// - Select Character & Game Mode: diamonds dan coins
public class EclipseProfileBinder : MonoBehaviour
{
    EclipseStyledLobbyBuilder lobby;
    EclipseGameHudBuilder hud;

    void OnEnable()
    {
        lobby = GetComponent<EclipseStyledLobbyBuilder>();
        hud = GetComponent<EclipseGameHudBuilder>();
        EclipsePlayerData.OnChanged += Apply;
        StartCoroutine(ApplyNextFrame()); // tunggu builder selesai membangun UI
    }

    void OnDisable()
    {
        EclipsePlayerData.OnChanged -= Apply;
    }

    IEnumerator ApplyNextFrame()
    {
        yield return null;
        Apply(EclipsePlayerData.Current);
    }

    Text Find(string name, string parentName)
    {
        foreach (var t in GetComponentsInChildren<Text>(true))
        {
            if (t.name != name) continue;
            if (parentName != null && (t.transform.parent == null || t.transform.parent.name != parentName)) continue;
            return t;
        }
        return null;
    }

    RectTransform FindRect(string name, string parentName)
    {
        foreach (var r in GetComponentsInChildren<RectTransform>(true))
        {
            if (r.name != name) continue;
            if (parentName != null && (r.parent == null || r.parent.name != parentName)) continue;
            return r;
        }
        return null;
    }

    static void Set(Text t, string v)
    {
        if (t != null && t.text != v) t.text = v;
    }

    static void Width(RectTransform r, float w)
    {
        if (r != null) r.sizeDelta = new Vector2(w, r.sizeDelta.y);
    }

    void Apply(EclipsePlayerProfile p)
    {
        if (p == null) return;
        string dia = p.diamonds.ToString("N0"), coin = p.coins.ToString("N0");
        float ratio = Mathf.Clamp01(p.expMax > 0 ? (float)p.exp / p.expMax : 0f);

        if (hud != null)
        {
            // HUD memperbarui teksnya sendiri dari field ini
            hud.playerName = p.name;
            hud.level = p.level;
            hud.exp = p.exp;
            hud.expMax = p.expMax;
            hud.rankText = p.rank;
            hud.diamonds = p.diamonds;
            hud.coins = p.coins;
            return;
        }

        if (lobby != null)
        {
            lobby.playerName = p.name;
            lobby.level = p.level;
            lobby.diamonds = p.diamonds;
            lobby.coins = p.coins;
            Set(Find("PlayerName", "ProfileGroup"), p.name);
            Set(Find("Level", "ProfileGroup"), "Lv. " + p.level);
            Set(Find("Experience", "ProfileGroup"), "EXP " + p.exp.ToString("N0") + " / " + p.expMax.ToString("N0"));
            Set(Find("Rank", "ProfileGroup"), p.rank);
            Width(FindRect("XPFill", "ProfileGroup"), 190f * ratio);
            Width(FindRect("XPLine", "ProfileGroup"), 190f * ratio);
        }

        // dompet (Lobby, Select Character, Game Mode)
        Set(Find("Balance", "Diamonds"), dia);
        Set(Find("Balance", "Coins"), coin);
    }
}
