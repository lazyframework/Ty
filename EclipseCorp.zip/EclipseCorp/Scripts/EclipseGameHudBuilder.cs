using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

// HUD in-game Project Eclipse (overlay di atas scene 3D, tanpa latar).
// Responsif: tiap kelompok menempel ke sudut/sisi layar. Dibangun langsung di editor.
public class EclipseGameHudBuilder : MonoBehaviour
{
    [Header("Opsional: gambar sendiri (kosong = placeholder)")]
    public Font font;
    public Sprite portrait, rankShield, missionIcon, objectiveIcon1, objectiveIcon2;
    public Sprite gem, coin, bell, gearTop, clock;
    public RenderTexture minimapTexture;
    public Sprite minimapArt, minimapPlayer, minimapObjective;
    public Sprite abilityQ, abilityE, abilityR;
    public Sprite reloadIcon, sprintIcon, aimIcon, fireIcon, crouchIcon, proneIcon;
    public Sprite weaponPrimary, weaponSecondary, grenadeIcon, medkitIcon, hpIcon, armorIcon;

    [Header("Profil")]
    public string playerName = "FamaLine";
    public int level = 12, exp = 720, expMax = 2000;
    public string rankText = "Silver III";
    public int diamonds = 1200, coins = 15340;

    [Header("Misi")]
    public string missionTitle = "Main Mission";
    public string objective1 = "Infiltrate the Research Facility";
    public string objective2 = "Reach the Control Room (0/1)";
    public float timerSeconds = 14 * 60 + 32;
    public bool timerCountsDown = false;
    public bool timerRunning = false;

    [Header("Kompas")]
    [Range(0, 360)] public float heading = 330;
    [Tooltip("Opsional: kamera/objek pemain. Kalau diisi, kompas mengikuti rotasi Y-nya.")]
    public Transform headingSource;

    [Header("Status")]
    public int hp = 100, maxHp = 100, armor = 100, maxArmor = 100;
    public int primaryAmmo = 30, primaryReserve = 120;
    public int secondaryAmmo = 15, secondaryReserve = 45;
    public int grenades = 2, medkits = 1;
    [Range(0, 1)] public int selectedWeapon = 0;
    public bool autoRefresh = true;

    [Serializable] public class HudEvent : UnityEvent<string, bool> { }
    [Tooltip("Dipanggil saat tombol HUD ditekan (true) dan dilepas (false). Id = nama objek, mis. Fire, Aim, Reload, AbilityQ.")]
    public HudEvent onHud = new HudEvent();
    [Serializable] public class MoveEvent : UnityEvent<Vector2> { }
    public MoveEvent onMove = new MoveEvent();

    [Header("Input System (baru)")]
    [Tooltip("Joystick layar mengirim Vector2 ke kontrol ini. Baca lewat InputAction/PlayerInput seperti gamepad biasa.")]
    public string leftStickControlPath = "<Gamepad>/leftStick";

    public Color cyan = new Color(.15f, .65f, 1, 1);

    const string Root = "EclipseHudCanvas_v1";

    RectTransform frame;
    readonly Dictionary<Transform, Vector2> origin = new Dictionary<Transform, Vector2>();
    Dictionary<string, Transform> map;

    enum HA { Left, Center, Right }
    enum VA { Top, Center, Bottom }
    HA ha = HA.Left;
    VA va = VA.Top;

    static Sprite sFill, sLine, sGlow, sRing, sDisc;

    static readonly Color Txt = new Color(.95f, .97f, 1f);
    static readonly Color Dim = new Color(.7f, .8f, .95f);
    static readonly Color HudFill = new Color(.01f, .04f, .10f, .62f);
    static readonly Color HudLine = new Color(.22f, .45f, .8f, .8f);
    static readonly Color BrightLine = new Color(.40f, .78f, 1f, 1f);
    static readonly Color Track = new Color(.85f, .9f, 1f, .22f);

    // ---------------------------------------------------------------- lifecycle

    void Start()
    {
        var root = transform.Find(Root);
        if (root == null) Build();
        else Wire(root);
        Refresh();
    }

    void Update()
    {
        if (!Application.isPlaying || !autoRefresh) return;
        if (headingSource != null) heading = headingSource.eulerAngles.y;
        if (timerRunning) timerSeconds = timerCountsDown ? Mathf.Max(0, timerSeconds - Time.deltaTime) : timerSeconds + Time.deltaTime;
        Refresh();
    }

#if UNITY_EDITOR
    void Reset()
    {
        UnityEditor.EditorApplication.delayCall += () => { if (this != null && transform.Find(Root) == null) Build(); };
    }
#endif

    void Wire(Transform root)
    {
        foreach (var b in root.GetComponentsInChildren<EclipseHudButton>(true))
        {
            b.id = b.gameObject.name;
            b.callback = OnHud;
        }
        foreach (var j in root.GetComponentsInChildren<EclipseVirtualJoystick>(true))
            j.callback = OnMove;
    }

    void OnHud(string id, bool pressed)
    {
        if (pressed)
        {
            if (id == "WeaponPrimary") selectedWeapon = 0;
            else if (id == "WeaponSecondary") selectedWeapon = 1;
        }
        onHud.Invoke(id, pressed);
    }

    void OnMove(Vector2 v) { onMove.Invoke(v); }

    // ---------------------------------------------------------------- API untuk game

    public void SetHp(int value, int max) { hp = value; maxHp = max; }
    public void SetArmor(int value, int max) { armor = value; maxArmor = max; }
    public void SetPrimaryAmmo(int cur, int reserve) { primaryAmmo = cur; primaryReserve = reserve; }
    public void SetSecondaryAmmo(int cur, int reserve) { secondaryAmmo = cur; secondaryReserve = reserve; }
    public void SetMission(string title, string o1, string o2) { missionTitle = title; objective1 = o1; objective2 = o2; }
    public void SetHeading(float degrees) { heading = degrees; }

    // ---------------------------------------------------------------- refresh

    Transform Get(string n)
    {
        Transform t;
        if (map != null && map.TryGetValue(n, out t) && t != null) return t;
        var root = transform.Find(Root);
        if (root == null) return null;
        map = new Dictionary<string, Transform>();
        foreach (var x in root.GetComponentsInChildren<Transform>(true))
            if (!map.ContainsKey(x.name)) map.Add(x.name, x);
        map.TryGetValue(n, out t);
        return t;
    }

    void SetText(string n, string v)
    {
        var t = Get(n);
        if (t == null) return;
        var tx = t.GetComponent<Text>();
        if (tx != null && tx.text != v) tx.text = v;
    }

    void SetSprite(string n, Sprite s)
    {
        var t = Get(n);
        if (t == null) return;
        var im = t.GetComponent<Image>();
        if (im != null && im.sprite != s) { im.sprite = s; im.enabled = s != null; }
    }

    void SetWidth(string n, float w)
    {
        var rt = Get(n) as RectTransform;
        if (rt != null && !Mathf.Approximately(rt.sizeDelta.x, w)) rt.sizeDelta = new Vector2(w, rt.sizeDelta.y);
    }

    static string Dir(int deg)
    {
        deg = ((deg % 360) + 360) % 360;
        switch (deg)
        {
            case 0: return "N";
            case 45: return "NE";
            case 90: return "E";
            case 135: return "SE";
            case 180: return "S";
            case 225: return "SW";
            case 270: return "W";
            case 315: return "NW";
        }
        return deg.ToString();
    }

    public void Refresh()
    {
        if (transform.Find(Root) == null) return;

        SetText("PlayerName", playerName);
        SetText("LevelText", "Lv. " + level);
        SetText("ExpText", exp.ToString("N0") + " / " + expMax.ToString("N0"));
        SetWidth("XPFill", 74f * Mathf.Clamp01(expMax > 0 ? (float)exp / expMax : 0));
        SetText("RankText", rankText);
        SetText("DiamondsBalance", diamonds.ToString("N0"));
        SetText("CoinsBalance", coins.ToString("N0"));

        SetText("MissionTitle", missionTitle);
        SetText("Objective1", objective1);
        SetText("Objective2", objective2);

        int t = Mathf.Max(0, Mathf.FloorToInt(timerSeconds));
        SetText("TimerText", (t / 60).ToString("00") + ":" + (t % 60).ToString("00"));

        // kompas
        float h = ((heading % 360f) + 360f) % 360f;
        float baseDeg = Mathf.Round(h / 15f) * 15f;
        float frac = (h - baseDeg) / 15f;
        SetText("CompassCenter", Mathf.RoundToInt(h).ToString());
        for (int k = 0; k < 11; k++)
        {
            var slot = Get("Compass" + k) as RectTransform;
            if (slot == null) continue;
            float x = ((k - 5) - frac) * 54.5f;
            slot.anchoredPosition = new Vector2(x, slot.anchoredPosition.y);
            SetText("Compass" + k, Dir(Mathf.RoundToInt(baseDeg) + (k - 5) * 15));
            var tx = slot.GetComponent<Text>();
            if (tx != null)
            {
                float a = Mathf.Clamp01((280f - Mathf.Abs(x)) / 120f) * Mathf.Clamp01((Mathf.Abs(x) - 22f) / 30f);
                var c = tx.color; c.a = a; tx.color = c;
            }
        }

        // status
        SetText("HpText", "HP " + hp);
        SetWidth("HpFill", 290f * Mathf.Clamp01(maxHp > 0 ? (float)hp / maxHp : 0));
        SetText("ArmorText", "Armor " + armor);
        SetWidth("ArmorFill", 290f * Mathf.Clamp01(maxArmor > 0 ? (float)armor / maxArmor : 0));

        SetText("PrimaryAmmo", primaryAmmo.ToString());
        SetText("PrimaryReserve", "/ " + primaryReserve);
        SetText("SecondaryAmmo", secondaryAmmo + " / " + secondaryReserve);
        SetText("GrenadeCount", grenades.ToString());
        SetText("MedkitCount", medkits.ToString());
        SetWeaponHighlight("WeaponPrimary", selectedWeapon == 0);
        SetWeaponHighlight("WeaponSecondary", selectedWeapon == 1);

        SetSprite("OwnPortrait", portrait);
        SetSprite("RankIcon", rankShield);
        SetSprite("MissionIcon", missionIcon);
        SetSprite("Objective1Icon", objectiveIcon1);
        SetSprite("Objective2Icon", objectiveIcon2);
        SetSprite("DiamondsIcon", gem);
        SetSprite("CoinsIcon", coin);
        SetSprite("BellIcon", bell);
        SetSprite("SettingsIcon", gearTop);
        SetSprite("ClockIcon", clock);
        SetSprite("MinimapArt", minimapArt);
        SetSprite("MinimapPlayer", minimapPlayer);
        SetSprite("MinimapObjective", minimapObjective);
        SetSprite("AbilityQIcon", abilityQ);
        SetSprite("AbilityEIcon", abilityE);
        SetSprite("AbilityRIcon", abilityR);
        SetSprite("ReloadIcon", reloadIcon);
        SetSprite("SprintIcon", sprintIcon);
        SetSprite("AimIcon", aimIcon);
        SetSprite("FireIcon", fireIcon);
        SetSprite("CrouchIcon", crouchIcon);
        SetSprite("ProneIcon", proneIcon);
        SetSprite("WeaponPrimaryIcon", weaponPrimary);
        SetSprite("WeaponSecondaryIcon", weaponSecondary);
        SetSprite("GrenadeIcon", grenadeIcon);
        SetSprite("MedkitIcon", medkitIcon);
        SetSprite("HpIcon", hpIcon);
        SetSprite("ArmorIcon", armorIcon);
    }

    void SetWeaponHighlight(string id, bool on)
    {
        var r = Get(id);
        if (r == null) return;
        var o = r.Find("Outline");
        var f = r.Find("Fill");
        if (o != null) o.GetComponent<Image>().color = on ? BrightLine : new Color(.5f, .6f, .75f, .55f);
        if (f != null) f.GetComponent<Image>().color = on ? new Color(.03f, .14f, .42f, .85f) : new Color(.03f, .05f, .1f, .6f);
    }

    // ---------------------------------------------------------------- helpers

    RectTransform NewRT(Transform p, string n)
    {
        var rt = new GameObject(n, typeof(RectTransform)).GetComponent<RectTransform>();
        rt.SetParent(p, false);
        return rt;
    }

    RectTransform R(Transform p, string n, float x, float y, float w, float h)
    {
        var r = NewRT(p, n);
        Vector2 o;
        origin.TryGetValue(p, out o);
        r.pivot = new Vector2(0, 1);
        if (p == frame)
        {
            float ax = ha == HA.Left ? 0 : (ha == HA.Right ? 1672 : 836);
            float ay = va == VA.Top ? 0 : (va == VA.Bottom ? 941 : 470.5f);
            r.anchorMin = r.anchorMax = new Vector2(ha == HA.Left ? 0 : (ha == HA.Right ? 1 : .5f),
                                                    va == VA.Top ? 1 : (va == VA.Bottom ? 0 : .5f));
            r.anchoredPosition = new Vector2(x - ax, -(y - ay));
        }
        else
        {
            r.anchorMin = r.anchorMax = new Vector2(0, 1);
            r.anchoredPosition = new Vector2(x - o.x, -(y - o.y));
        }
        r.sizeDelta = new Vector2(w, h);
        origin[r] = new Vector2(x, y);
        return r;
    }

    Image Img(Transform p, string n, float x, float y, float w, float h, Sprite s, Color c, bool sliced = false, bool ray = false)
    {
        var i = R(p, n, x, y, w, h).gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = c;
        i.raycastTarget = ray;
        if (s != null)
        {
            if (sliced) i.type = Image.Type.Sliced;
            else i.preserveAspect = true;
        }
        return i;
    }

    Image S(Transform p, string n, float x, float y, float w, float h, Color c) { return Img(p, n, x, y, w, h, null, c); }

    Text T(Transform p, string n, string s, float x, float cy, float w, int size, bool bold = false,
           TextAnchor a = TextAnchor.MiddleLeft, bool italic = false, Color? col = null)
    {
        float h = size * 1.6f;
        var t = R(p, n, x, cy - h / 2f, w, h).gameObject.AddComponent<Text>();
        t.font = font;
        t.text = s;
        t.fontSize = size;
        t.fontStyle = bold ? (italic ? FontStyle.BoldAndItalic : FontStyle.Bold) : (italic ? FontStyle.Italic : FontStyle.Normal);
        t.color = col ?? Txt;
        t.alignment = a;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    Image Icon(Transform p, string n, Sprite sprite, float x, float y, float w, float h)
    {
        var i = Img(p, n, x, y, w, h, sprite, Color.white);
        i.preserveAspect = true;
        i.gameObject.AddComponent<EclipseIconSlot>();
        return i;
    }

    RectTransform Panel(Transform p, string n, float x, float y, float w, float h, Color fill, Color line, float glow = 0)
    {
        var r = R(p, n, x, y, w, h);
        if (glow > 0) Img(r, "Glow", x - 20, y - 20, w + 40, h + 40, GlowSprite(), new Color(.1f, .5f, 1f, glow), true);
        Img(r, "Fill", x, y, w, h, FillSprite(), fill, true);
        Img(r, "Outline", x, y, w, h, LineSprite(), line, true);
        return r;
    }

    // gambar di dalam panel: di atas Fill, di bawah Outline
    Image ArtAbove(RectTransform panel, string n, float x, float y, float w, float h)
    {
        var i = Img(panel, n, x, y, w, h, null, Color.white);
        i.preserveAspect = false;
        i.gameObject.AddComponent<EclipseIconSlot>();
        var o = panel.Find("Outline");
        if (o != null) i.transform.SetSiblingIndex(o.GetSiblingIndex());
        return i;
    }

    // Chevron dengan rotasi: 0 = "<", -90 = "^", 180 = ">", 90 = "v"
    void Chev(Transform p, string n, float cx, float cy, float w, float s, float th, Color c, float rot)
    {
        var g = R(p, n, cx - 1, cy - 1, 2, 2);
        g.pivot = new Vector2(.5f, .5f);
        g.anchoredPosition += new Vector2(1, -1);
        g.localEulerAngles = new Vector3(0, 0, rot);
        float L = Mathf.Sqrt(4 * w * w + s * s) + th * .5f;
        float ang = Mathf.Atan2(s, 2 * w) * Mathf.Rad2Deg;
        for (int k = 0; k < 2; k++)
        {
            bool up = k == 0;
            var a = NewRT(g, n + (up ? "A" : "B"));
            a.anchorMin = a.anchorMax = new Vector2(.5f, .5f);
            a.pivot = new Vector2(.5f, .5f);
            a.sizeDelta = new Vector2(L, th);
            a.anchoredPosition = new Vector2(0, up ? s / 2f : -s / 2f);
            a.localEulerAngles = new Vector3(0, 0, up ? ang : -ang);
            var im = a.gameObject.AddComponent<Image>();
            im.color = c;
            im.raycastTarget = false;
        }
    }

    // jadikan root sebagai tombol HUD (tekan/lepas)
    void Hud(RectTransform root)
    {
        var fill = root.Find("Fill");
        if (fill != null) fill.GetComponent<Graphic>().raycastTarget = true;
        else
        {
            var hit = NewRT(root, "Hit");
            hit.anchorMin = Vector2.zero; hit.anchorMax = Vector2.one; hit.offsetMin = hit.offsetMax = Vector2.zero;
            var im = hit.gameObject.AddComponent<Image>();
            im.color = new Color(0, 0, 0, 0);
            im.raycastTarget = true;
        }
        root.gameObject.AddComponent<CanvasGroup>();
        var hb = root.gameObject.AddComponent<EclipseHudButton>();
        hb.id = root.name;
        hb.callback = OnHud;
    }

    // tombol bulat: cakram gelap + cincin + ikon (+ huruf tombol)
    RectTransform Circle(string id, float cx, float cy, float d, float inset, string key)
    {
        float x = cx - d / 2f, y = cy - d / 2f;
        var r = R(frame, id, x, y, d, d);
        Img(r, "Fill", x, y, d, d, DiscSprite(), new Color(.02f, .05f, .12f, .72f));
        Img(r, "Outline", x, y, d, d, RingSprite(), new Color(.78f, .88f, 1f, .9f));
        Icon(r, id + "Icon", null, x + inset, y + inset, d - inset * 2, d - inset * 2);
        if (!string.IsNullOrEmpty(key))
            T(r, id + "Key", key, x + d * .62f, y + d * .86f, d * .38f, 14, true, TextAnchor.MiddleCenter);
        Hud(r);
        return r;
    }

    // ---------------------------------------------------------------- sprite generator (PNG nyata di editor)

    static float Sd(float x, float y, float x0, float y0, float x1, float y1, float c)
    {
        float d = Mathf.Min(Mathf.Min(x - x0, x1 - x), Mathf.Min(y - y0, y1 - y));
        float tl = ((x - x0) + (y1 - y) - c) * 0.70710678f;
        float br = ((x1 - x) + (y - y0) - c) * 0.70710678f;
        return Mathf.Min(d, Mathf.Min(tl, br));
    }

    static Sprite Make(string name, int w, int h, int border, Func<float, float, Color> px)
    {
#if UNITY_EDITOR
        const string dir = "Assets/EclipseLobby/Generated";
        string path = dir + "/" + name + ".png";
        var existing = UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (existing != null) return existing;
#endif
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.name = name;
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        var cols = new Color32[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                cols[y * w + x] = px(x + .5f, y + .5f);
        t.SetPixels32(cols);
        t.Apply();
#if UNITY_EDITOR
        System.IO.Directory.CreateDirectory(dir);
        System.IO.File.WriteAllBytes(path, t.EncodeToPNG());
        UnityEngine.Object.DestroyImmediate(t);
        UnityEditor.AssetDatabase.ImportAsset(path, UnityEditor.ImportAssetOptions.ForceSynchronousImport);
        var ti = (UnityEditor.TextureImporter)UnityEditor.AssetImporter.GetAtPath(path);
        ti.textureType = UnityEditor.TextureImporterType.Sprite;
        ti.spriteImportMode = UnityEditor.SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 100;
        ti.spriteBorder = new Vector4(border, border, border, border);
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.filterMode = FilterMode.Bilinear;
        ti.textureCompression = UnityEditor.TextureImporterCompression.Uncompressed;
        ti.SaveAndReimport();
        return UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
#else
        var s = Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect,
                              new Vector4(border, border, border, border));
        s.name = name;
        return s;
#endif
    }

    static Sprite FillSprite()
    {
        if (sFill == null)
            sFill = Make("EclipseFill", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f);
                float g = Mathf.Lerp(.72f, 1f, y / 64f);
                return new Color(g, g, g, a);
            });
        return sFill;
    }

    static Sprite LineSprite()
    {
        if (sLine == null)
            sLine = Make("EclipseLine", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f) * Mathf.Clamp01(2.1f - d);
                return new Color(1, 1, 1, a);
            });
        return sLine;
    }

    static Sprite GlowSprite()
    {
        if (sGlow == null)
            sGlow = Make("EclipseGlow", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 20, 20, 44, 44, 12);
                float a = d >= 0 ? 1f : Mathf.Pow(Mathf.Clamp01(1f + d / 20f), 2.2f);
                return new Color(1, 1, 1, a);
            });
        return sGlow;
    }

    static Sprite RingSprite()
    {
        if (sRing == null)
            sRing = Make("EclipseRing", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(1.6f - Mathf.Abs(r - 14.2f) + .5f));
            });
        return sRing;
    }

    static Sprite DiscSprite()
    {
        if (sDisc == null)
            sDisc = Make("EclipseDisc", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(15f - r));
            });
        return sDisc;
    }

    // ---------------------------------------------------------------- build

    [ContextMenu("Build Game HUD")]
    public void Build()
    {
        Transform old;
        while ((old = transform.Find(Root)) != null)
        {
            old.gameObject.SetActive(false);
            old.SetParent(null);
            if (Application.isPlaying) Destroy(old.gameObject);
            else DestroyImmediate(old.gameObject);
        }
        origin.Clear();
        map = null;

        if (font == null)
        {
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        var go = new GameObject(Root, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.transform.SetParent(transform, false);
        go.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scale = go.GetComponent<CanvasScaler>();
        scale.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scale.referenceResolution = new Vector2(1672, 941);
        scale.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;

        frame = new GameObject("ReferenceFrame", typeof(RectTransform)).GetComponent<RectTransform>();
        frame.SetParent(go.transform, false);
        frame.anchorMin = Vector2.zero;
        frame.anchorMax = Vector2.one;
        frame.offsetMin = frame.offsetMax = Vector2.zero;
        frame.gameObject.AddComponent<EclipseSafeArea>();
        origin[frame] = Vector2.zero;

        TopLeft();
        Compass();
        TopRight();
        Abilities();
        RightControls();
        LeftControls();
        BottomBar();

#if UNITY_2023_1_OR_NEWER
        bool noES = UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null;
#else
        bool noES = UnityEngine.Object.FindObjectOfType<EventSystem>() == null;
#endif
        if (noES)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        Wire(go.transform);
        Refresh();
    }

    // ---------------------------------------------------------------- kiri atas: profil + misi

    void TopLeft()
    {
        ha = HA.Left; va = VA.Top;

        var card = Panel(frame, "ProfileCard", 24, 20, 322, 130, HudFill, new Color(.2f, .4f, .7f, .45f));
        foreach (var g in card.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        var pf = Panel(card, "Portrait", 26, 22, 112, 110, Color.clear, BrightLine);
        ArtAbove(pf, "OwnPortrait", 28, 24, 108, 106);
        foreach (var g in pf.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        T(card, "PlayerName", "", 159, 46, 180, 22, true);
        T(card, "LevelText", "", 159, 78, 70, 22, true);
        S(card, "XPTrack", 232, 76, 74, 6, new Color(.08f, .16f, .32f, .9f));
        S(card, "XPFill", 232, 76, 74, 6, cyan);
        T(card, "ExpText", "", 312, 80, 90, 15, false, TextAnchor.MiddleLeft, false, Dim);
        Icon(card, "RankIcon", null, 160, 100, 44, 46);
        T(card, "RankText", "", 215, 126, 100, 18, true);
        Img(card, "InfoRing", 294, 115, 22, 22, RingSprite(), Dim);
        T(card, "Info", "i", 294, 126, 22, 13, false, TextAnchor.MiddleCenter, true, Dim);

        var m = Panel(frame, "MissionCard", 24, 158, 314, 118, HudFill, new Color(.2f, .4f, .7f, .45f));
        foreach (var g in m.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;
        Icon(m, "MissionIcon", null, 34, 168, 32, 32);
        T(m, "MissionTitle", "", 72, 183, 230, 21, true, TextAnchor.MiddleLeft, false, new Color(.3f, .75f, 1f));
        Icon(m, "Objective1Icon", null, 40, 204, 22, 22);
        T(m, "Objective1", "", 72, 214, 262, 18);
        Icon(m, "Objective2Icon", null, 72, 235, 22, 22);
        T(m, "Objective2", "", 98, 245, 238, 18);
    }

    // ---------------------------------------------------------------- tengah atas: kompas

    void Compass()
    {
        ha = HA.Center; va = VA.Top;
        Img(frame, "CompassBar", 560, 26, 556, 44, FillSprite(), new Color(.01f, .04f, .1f, .3f), true);

        for (int k = 0; k < 11; k++)
        {
            float x = 836 + (k - 5) * 54.5f;
            var t = T(frame, "Compass" + k, "", x - 30, 49, 60, 16, false, TextAnchor.MiddleCenter, false, Txt);
            // pivot di tengah supaya anchoredPosition.x = jarak dari pusat
            t.rectTransform.pivot = new Vector2(.5f, t.rectTransform.pivot.y);
            t.rectTransform.anchoredPosition = new Vector2((k - 5) * 54.5f, t.rectTransform.anchoredPosition.y);
        }

        var c = Panel(frame, "CompassCapsule", 806, 26, 60, 42, new Color(.03f, .16f, .45f, .9f), BrightLine, .5f);
        foreach (var g in c.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;
        T(c, "CompassCenter", "", 806, 47, 60, 24, true, TextAnchor.MiddleCenter);
        var tip = S(c, "CompassTip", 831, 64, 10, 10, BrightLine);
        tip.rectTransform.localEulerAngles = new Vector3(0, 0, 45);
    }

    // ---------------------------------------------------------------- kanan atas: dompet, ikon, minimap

    void TopRight()
    {
        ha = HA.Right; va = VA.Top;
        Wallet("Diamonds", 1162, 146, "DiamondsIcon", "DiamondsBalance");
        Wallet("Coins", 1320, 152, "CoinsIcon", "CoinsBalance");

        var b = R(frame, "Notifications", 1508, 22, 46, 46);
        Icon(b, "BellIcon", null, 1510, 24, 40, 42);
        Img(b, "AlertBadge", 1533, 16, 18, 18, DiscSprite(), new Color(.86f, .08f, .12f));
        T(b, "Alert", "!", 1533, 25, 18, 11, true, TextAnchor.MiddleCenter);
        Hud(b);

        var s = R(frame, "Settings", 1572, 22, 52, 46);
        Icon(s, "SettingsIcon", null, 1574, 24, 48, 42);
        Hud(s);

        // minimap
        var mm = Panel(frame, "Minimap", 1435, 82, 212, 192, new Color(0, .02f, .06f, .5f), new Color(.65f, .75f, .9f, .85f));
        ArtAbove(mm, "MinimapArt", 1437, 84, 208, 188);
        if (minimapTexture != null)
        {
            var raw = R(mm, "MinimapRender", 1437, 84, 208, 188).gameObject.AddComponent<RawImage>();
            raw.texture = minimapTexture;
            raw.raycastTarget = false;
            raw.transform.SetSiblingIndex(mm.Find("Outline").GetSiblingIndex());
        }
        Icon(mm, "MinimapPlayer", null, 1525, 160, 36, 36);
        Icon(mm, "MinimapObjective", null, 1570, 112, 28, 28);
        T(mm, "MinimapN", "N", 1534, 95, 18, 13, true, TextAnchor.MiddleCenter);
        foreach (var g in mm.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        var tm = Panel(frame, "TimerBar", 1435, 278, 212, 34, new Color(0, .02f, .06f, .55f), new Color(.2f, .4f, .7f, .35f));
        foreach (var g in tm.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;
        Icon(tm, "ClockIcon", null, 1444, 281, 30, 28);
        T(tm, "TimerText", "", 1484, 296, 120, 22, true);
    }

    void Wallet(string id, float x, float w, string iconName, string balName)
    {
        var p = Panel(frame, id, x, 24, w, 40, new Color(.01f, .04f, .10f, .7f), new Color(.2f, .42f, .74f, .85f));
        Icon(p, iconName, null, x + 8, 25, 34, 38);
        T(p, balName, "", x + 50, 44, w - 90, 19, true);
        S(p, id + "Divider", x + w - 40, 28, 1, 32, new Color(.2f, .4f, .7f, .5f));
        T(p, id + "Plus", "+", x + w - 40, 44, 40, 28, false, TextAnchor.MiddleCenter);
        Hud(p);
    }

    // ---------------------------------------------------------------- kanan tengah: skill Q/E/R

    void Abilities()
    {
        ha = HA.Right; va = VA.Center;
        Circle("AbilityQ", 1611, 376, 76, 10, "Q");
        Circle("AbilityE", 1611, 460, 76, 10, "E");
        Circle("AbilityR", 1611, 544, 76, 10, "R");
    }

    // ---------------------------------------------------------------- kanan bawah: aim, tembak, crouch, prone

    void RightControls()
    {
        ha = HA.Right; va = VA.Bottom;
        Circle("Aim", 1510, 582, 92, 18, null);
        Circle("Fire", 1397, 708, 164, 40, null);
        Circle("Crouch", 1432, 857, 98, 18, null);
        Circle("Prone", 1574, 848, 98, 18, null);
    }

    // ---------------------------------------------------------------- kiri bawah: reload, sprint, joystick

    void LeftControls()
    {
        ha = HA.Left; va = VA.Bottom;
        Circle("Reload", 116, 462, 108, 24, null);
        Circle("Sprint", 246, 521, 90, 18, null);

        // joystick
        float cx = 227, cy = 698, d = 228;
        var j = R(frame, "Joystick", cx - d / 2, cy - d / 2, d, d);
        Img(j, "JoyBase", cx - d / 2, cy - d / 2, d, d, DiscSprite(), new Color(.02f, .05f, .12f, .38f), false, true);
        Img(j, "JoyRing", cx - d / 2 + 2, cy - d / 2 + 2, d - 4, d - 4, RingSprite(), new Color(.7f, .82f, 1f, .55f));
        Img(j, "JoyRingInner", cx - 74, cy - 74, 148, 148, RingSprite(), new Color(.7f, .82f, 1f, .25f));
        Chev(j, "JoyUp", cx, cy - 92, 8, 16, 3, new Color(.75f, .85f, 1f, .75f), -90);
        Chev(j, "JoyDown", cx, cy + 92, 8, 16, 3, new Color(.75f, .85f, 1f, .75f), 90);
        Chev(j, "JoyLeft", cx - 90, cy, 8, 16, 3, new Color(.75f, .85f, 1f, .75f), 0);
        Chev(j, "JoyRight", cx + 90, cy, 8, 16, 3, new Color(.75f, .85f, 1f, .75f), 180);

        var thumb = NewRT(j, "JoyThumb");
        thumb.anchorMin = thumb.anchorMax = new Vector2(.5f, .5f);
        thumb.pivot = new Vector2(.5f, .5f);
        thumb.sizeDelta = new Vector2(90, 90);
        thumb.anchoredPosition = Vector2.zero;
        var ti = thumb.gameObject.AddComponent<Image>();
        ti.sprite = DiscSprite();
        ti.color = new Color(.82f, .88f, .98f, .75f);
        ti.raycastTarget = false;
        var ring = NewRT(thumb, "JoyThumbRing");
        ring.anchorMin = Vector2.zero; ring.anchorMax = Vector2.one; ring.offsetMin = ring.offsetMax = Vector2.zero;
        var ri = ring.gameObject.AddComponent<Image>();
        ri.sprite = RingSprite();
        ri.color = new Color(1, 1, 1, .9f);
        ri.raycastTarget = false;

        var js = j.gameObject.AddComponent<EclipseVirtualJoystick>();
        js.thumb = thumb;
        js.radius = 62;
#if ENABLE_INPUT_SYSTEM
        js.controlPath = leftStickControlPath;
#endif
        js.callback = OnMove;
    }

    // ---------------------------------------------------------------- bawah tengah: senjata + HP/Armor

    void BottomBar()
    {
        ha = HA.Center; va = VA.Bottom;

        Img(frame, "StatusPlate", 505, 858, 720, 83, FillSprite(), new Color(0, .02f, .06f, .4f), true);

        var p = Panel(frame, "WeaponPrimary", 590, 774, 240, 76, HudFill, HudLine, .4f);
        Icon(p, "WeaponPrimaryIcon", null, 628, 780, 156, 50);
        T(p, "PrimaryAmmo", "", 614, 832, 60, 30, true);
        T(p, "PrimaryReserve", "", 654, 835, 100, 18, false, TextAnchor.MiddleLeft, false, Dim);
        Hud(p);

        var s = Panel(frame, "WeaponSecondary", 842, 780, 166, 70, HudFill, HudLine);
        Icon(s, "WeaponSecondaryIcon", null, 890, 786, 72, 40);
        T(s, "SecondaryAmmo", "", 856, 833, 120, 20, false, TextAnchor.MiddleLeft, false, Txt);
        Hud(s);

        var g = Panel(frame, "Grenade", 1022, 785, 86, 64, HudFill, HudLine);
        Icon(g, "GrenadeIcon", null, 1032, 792, 42, 44);
        T(g, "GrenadeCount", "", 1082, 833, 20, 18, false, TextAnchor.MiddleLeft);
        Hud(g);

        var m = Panel(frame, "Medkit", 1124, 785, 88, 64, HudFill, HudLine);
        Icon(m, "MedkitIcon", null, 1134, 792, 42, 44);
        T(m, "MedkitCount", "", 1186, 833, 20, 18, false, TextAnchor.MiddleLeft);
        Hud(m);

        // HP + Armor
        Icon(frame, "HpIcon", null, 509, 859, 28, 28);
        T(frame, "HpText", "", 542, 873, 90, 22, true);
        S(frame, "HpTrack", 631, 867, 290, 12, Track);
        S(frame, "HpFill", 631, 867, 290, 12, new Color(.9f, .94f, 1f, .95f));

        Icon(frame, "ArmorIcon", null, 511, 891, 24, 24);
        T(frame, "ArmorText", "", 541, 902, 90, 18, false, TextAnchor.MiddleLeft, false, new Color(.5f, .8f, 1f));
        S(frame, "ArmorTrack", 631, 897, 290, 12, Track);
        S(frame, "ArmorFill", 631, 897, 290, 12, new Color(.1f, .6f, 1f, .95f));
    }
}
