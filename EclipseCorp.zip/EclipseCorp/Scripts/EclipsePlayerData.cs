using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
#if ECLIPSE_FIREBASE
using Firebase;
using Firebase.Auth;
using Firebase.Database;
using Firebase.Extensions;
#endif

// Data profil pemain (disimpan per akun di Firebase Realtime Database: users/{uid}).
[Serializable]
public class EclipsePlayerProfile
{
    public string name = "Agent";
    public int level = 1;
    public int exp = 0;
    public int expMax = 1000;
    public string rank = "Bronze I";
    public int diamonds = 0;
    public int coins = 0;
}

// Layanan data pemain realtime.
// - Dibuat otomatis saat game mulai (tidak perlu dipasang manual) dan bertahan antar scene.
// - Mengikuti akun yang sedang login (FirebaseAuth). Akun baru otomatis dibuatkan profil awal.
// - Mendengarkan perubahan di server secara realtime; event OnChanged dipanggil tiap data berubah.
// - Otomatis memasang EclipseProfileBinder ke Lobby / HUD / Select Character / Game Mode.
// Prasyarat: simbol ECLIPSE_FIREBASE aktif, paket FirebaseDatabase.unitypackage sudah diimpor,
// dan Realtime Database sudah dibuat di Firebase Console (lihat aturan keamanan di bawah).
public class EclipsePlayerData : MonoBehaviour
{
    // Isi hanya kalau database dibuat di region non-default (mis. https://xxxx-default-rtdb.asia-southeast1.firebasedatabase.app).
    // Kosong = pakai firebase_url dari google-services.json.
    public static string DatabaseUrl = "";

    // Nilai awal akun baru
    public static int StartDiamonds = 0;
    public static int StartCoins = 0;

    public static EclipsePlayerData Instance { get; private set; }
    public static EclipsePlayerProfile Current { get; private set; }
    public static event Action<EclipsePlayerProfile> OnChanged;

    static string pendingName;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot()
    {
        if (Instance != null) return;
        var go = new GameObject("EclipsePlayerData");
        DontDestroyOnLoad(go);
        go.AddComponent<EclipsePlayerData>();
    }

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        SceneManager.sceneLoaded += OnSceneLoaded;
        AttachBinders();
    }

    void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
#if ECLIPSE_FIREBASE
        Detach();
        if (auth != null) auth.StateChanged -= OnAuthChanged;
#endif
        if (Instance == this) Instance = null;
    }

    void OnSceneLoaded(Scene s, LoadSceneMode m) { AttachBinders(); }

    static void Bind<T>() where T : MonoBehaviour
    {
#if UNITY_2023_1_OR_NEWER
        var all = UnityEngine.Object.FindObjectsByType<T>(FindObjectsSortMode.None);
#else
        var all = UnityEngine.Object.FindObjectsOfType<T>();
#endif
        foreach (var b in all)
            if (b.GetComponent<EclipseProfileBinder>() == null) b.gameObject.AddComponent<EclipseProfileBinder>();
    }

    static void AttachBinders()
    {
        Bind<EclipseStyledLobbyBuilder>();
        Bind<EclipseGameHudBuilder>();
        Bind<EclipseCharacterSelectBuilder>();
        Bind<EclipseGameModeBuilder>();
    }

    static void Publish(EclipsePlayerProfile p)
    {
        Current = p;
        if (p != null && !string.IsNullOrEmpty(p.name)) PlayerPrefs.SetString("EclipsePlayerName", p.name);
        if (OnChanged != null) OnChanged(p);
    }

#if !ECLIPSE_FIREBASE
    // Tanpa Firebase: API tetap ada supaya skrip lain bisa dikompilasi, tapi tidak melakukan apa-apa.
    void Start() { Debug.LogWarning("EclipsePlayerData: tambahkan simbol ECLIPSE_FIREBASE dan impor FirebaseDatabase agar data tersimpan di server."); }
    public static void SetName(string n) { pendingName = n; }
    public static void AddCoins(int amount) { }
    public static void AddDiamonds(int amount) { }
    public static void AddExp(int amount) { }
    public static void SetRank(string rank) { }
#else
    FirebaseAuth auth;
    DatabaseReference userRef;
    string uid;

    void Start()
    {
        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(t =>
        {
            if (t.Result != DependencyStatus.Available)
            {
                Debug.LogError("EclipsePlayerData: Firebase tidak tersedia (" + t.Result + ").");
                return;
            }
            auth = FirebaseAuth.DefaultInstance;
            auth.StateChanged += OnAuthChanged;
            OnAuthChanged(this, EventArgs.Empty);
        });
    }

    void OnAuthChanged(object sender, EventArgs e)
    {
        var user = auth != null ? auth.CurrentUser : null;
        if (user == null) { Detach(); uid = null; Publish(null); return; }
        if (user.UserId == uid) return;
        Detach();
        uid = user.UserId;
        Attach(user);
    }

    DatabaseReference Root()
    {
        var db = string.IsNullOrEmpty(DatabaseUrl) ? FirebaseDatabase.DefaultInstance : FirebaseDatabase.GetInstance(DatabaseUrl);
        return db.RootReference;
    }

    void Attach(FirebaseUser user)
    {
        var r = Root().Child("users").Child(user.UserId);
        userRef = r;
        r.GetValueAsync().ContinueWithOnMainThread(t =>
        {
            if (userRef != r) return; // akun sudah berganti
            if (t.IsFaulted || t.IsCanceled)
            {
                Debug.LogError("EclipsePlayerData: gagal membaca profil. " + (t.Exception != null ? t.Exception.GetBaseException().Message : ""));
                return;
            }
            if (!t.Result.Exists)
            {
                var p = new EclipsePlayerProfile();
                p.name = !string.IsNullOrEmpty(pendingName) ? pendingName : DefaultName(user);
                p.diamonds = StartDiamonds;
                p.coins = StartCoins;
                r.SetRawJsonValueAsync(JsonUtility.ToJson(p)).ContinueWithOnMainThread(c =>
                {
                    if (c.IsFaulted) Debug.LogError("EclipsePlayerData: gagal membuat profil. " + c.Exception.GetBaseException().Message);
                });
                pendingName = null;
            }
            else if (!string.IsNullOrEmpty(pendingName))
            {
                r.Child("name").SetValueAsync(pendingName);
                pendingName = null;
            }
            r.ValueChanged += OnValue; // realtime: dipanggil sekarang dan setiap data berubah
        });
    }

    void Detach()
    {
        if (userRef != null) userRef.ValueChanged -= OnValue;
        userRef = null;
    }

    void OnValue(object sender, ValueChangedEventArgs e)
    {
        if (e.DatabaseError != null) { Debug.LogError("EclipsePlayerData: " + e.DatabaseError.Message); return; }
        if (e.Snapshot == null || !e.Snapshot.Exists) return;
        var p = JsonUtility.FromJson<EclipsePlayerProfile>(e.Snapshot.GetRawJsonValue());
        if (p != null) Publish(p);
    }

    static string DefaultName(FirebaseUser u)
    {
        if (!string.IsNullOrEmpty(u.DisplayName)) return u.DisplayName;
        if (!string.IsNullOrEmpty(u.Email)) return u.Email.Split('@')[0];
        return u.IsAnonymous ? "Guest" : "Agent";
    }

    // ------------------------------------------------------------ API untuk game

    // Dipanggil setelah register (nama pilihan pemain). Aman dipanggil sebelum profil siap.
    public static void SetName(string n)
    {
        if (string.IsNullOrEmpty(n)) return;
        if (Instance != null && Instance.userRef != null) Instance.userRef.Child("name").SetValueAsync(n);
        else pendingName = n;
    }

    public static void AddCoins(int amount) { AddNumber("coins", amount); }
    public static void AddDiamonds(int amount) { AddNumber("diamonds", amount); }

    public static void SetRank(string rank)
    {
        if (Instance != null && Instance.userRef != null) Instance.userRef.Child("rank").SetValueAsync(rank);
    }

    // Tambah/kurangi angka dengan transaksi (aman kalau dua perangkat mengubah bersamaan).
    // Saldo tidak akan menjadi negatif: pengurangan yang melebihi saldo dibatalkan.
    static void AddNumber(string key, int delta)
    {
        if (Instance == null || Instance.userRef == null) return;
        Instance.userRef.Child(key).RunTransaction(m =>
        {
            long cur = 0;
            if (m.Value != null) long.TryParse(m.Value.ToString(), out cur);
            long n = cur + delta;
            if (n < 0) return TransactionResult.Abort();
            m.Value = n;
            return TransactionResult.Success(m);
        });
    }

    // Tambah EXP dan naik level otomatis (EXP maksimum naik 15% tiap level).
    public static void AddExp(int amount)
    {
        if (Instance == null || Instance.userRef == null || amount <= 0) return;
        Instance.userRef.RunTransaction(m =>
        {
            var d = m.Value as Dictionary<string, object>;
            if (d == null) return TransactionResult.Abort();
            int level = Geti(d, "level", 1), exp = Geti(d, "exp", 0) + amount, max = Geti(d, "expMax", 1000);
            if (max <= 0) max = 1000;
            while (exp >= max) { exp -= max; level++; max = Mathf.RoundToInt(max * 1.15f); }
            d["level"] = (long)level;
            d["exp"] = (long)exp;
            d["expMax"] = (long)max;
            m.Value = d;
            return TransactionResult.Success(m);
        });
    }

    static int Geti(Dictionary<string, object> d, string key, int fallback)
    {
        object o;
        long v;
        if (d.TryGetValue(key, out o) && o != null && long.TryParse(o.ToString(), out v)) return (int)v;
        return fallback;
    }
#endif
}
