using System;
using UnityEngine;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.Layouts;
using UnityEngine.InputSystem.OnScreen;
#endif

// Joystick virtual untuk Input System (baru).
// - Dengan Input System aktif: ini adalah OnScreenControl yang mengirim Vector2 ke "<Gamepad>/leftStick"
//   (atau path lain di Control Path), jadi bisa dibaca lewat InputAction / PlayerInput seperti gamepad biasa.
// - Tanpa Input System: tetap berfungsi lewat event Action<Vector2> (callback) dan properti value.
// Tidak memakai kelas Input lama sama sekali; hanya event pointer dari EventSystem.
public class EclipseVirtualJoystick :
#if ENABLE_INPUT_SYSTEM
    OnScreenControl,
#else
    MonoBehaviour,
#endif
    IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform thumb;
    public float radius = 60f;
    public Action<Vector2> callback;
    public Vector2 value { get; private set; }

#if ENABLE_INPUT_SYSTEM
    [InputControl(layout = "Vector2")]
    [SerializeField] string m_ControlPath = "<Gamepad>/leftStick";

    protected override string controlPathInternal
    {
        get { return m_ControlPath; }
        set { m_ControlPath = value; }
    }
#endif

    public void OnPointerDown(PointerEventData e) { Move(e); }
    public void OnDrag(PointerEventData e) { Move(e); }
    public void OnPointerUp(PointerEventData e) { Set(Vector2.zero); }

    void Move(PointerEventData e)
    {
        var rt = transform as RectTransform;
        Vector2 local;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(rt, e.position, e.pressEventCamera, out local)) return;
        // pusat rect (pivot kiri-atas) -> koordinat relatif pusat
        Vector2 c = new Vector2((0.5f - rt.pivot.x) * rt.rect.width, (0.5f - rt.pivot.y) * rt.rect.height);
        Vector2 d = Vector2.ClampMagnitude(local - c, radius);
        Set(d / radius);
    }

    void Set(Vector2 v)
    {
        value = v;
        if (thumb != null) thumb.anchoredPosition = v * radius;
#if ENABLE_INPUT_SYSTEM
        SendValueToControl(v);
#endif
        if (callback != null) callback(v);
    }
}
