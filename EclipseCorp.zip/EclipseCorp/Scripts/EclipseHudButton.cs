using System;
using UnityEngine;
using UnityEngine.EventSystems;

// Tombol HUD: melaporkan tekan (true) dan lepas (false). Cocok untuk tombol tembak/aim yang ditahan.
public class EclipseHudButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public string id;
    public Action<string, bool> callback;
    bool down;

    public void OnPointerDown(PointerEventData e)
    {
        if (down) return;
        down = true;
        var cg = GetComponent<CanvasGroup>();
        if (cg != null) cg.alpha = .7f;
        if (callback != null) callback(id, true);
    }

    public void OnPointerUp(PointerEventData e) { Release(); }
    void OnDisable() { Release(); }

    void Release()
    {
        if (!down) return;
        down = false;
        var cg = GetComponent<CanvasGroup>();
        if (cg != null) cg.alpha = 1f;
        if (callback != null) callback(id, false);
    }
}
