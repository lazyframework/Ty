using System.Collections.Generic;
using UnityEngine;

// Daftar agen bersama untuk semua scene (Select Character, GameScene, dst).
// Buat lewat: Tools > Project Eclipse > Create Agent Database  (atau klik kanan Project > Create > Project Eclipse > Agent Database).
// Isi Model Prefab tiap agen di sini; layar Select Character dan GameScene akan membaca daftar yang sama.
[CreateAssetMenu(fileName = "EclipseAgentDatabase", menuName = "Project Eclipse/Agent Database")]
public class EclipseAgentDatabase : ScriptableObject
{
    public List<EclipseAgentData> agents = new List<EclipseAgentData>();

    public int Count { get { return agents != null ? agents.Count : 0; } }

    public EclipseAgentData Get(int index)
    {
        if (agents == null || agents.Count == 0) return null;
        return agents[Mathf.Clamp(index, 0, agents.Count - 1)];
    }

    // Agen contoh (tanpa model). Ganti isinya dengan karakter aslimu.
    public static List<EclipseAgentData> CreateDefaults()
    {
        var l = new List<EclipseAgentData>();
        l.Add(new EclipseAgentData("Agent 013", "Assault", 12));
        l.Add(new EclipseAgentData("Agent 021", "Recon", 9) { hp = 85, armor = 60, attack = 80, speed = 110 });
        l.Add(new EclipseAgentData("Agent 034", "Support", 8) { hp = 95, armor = 75, attack = 60, speed = 90 });
        l.Add(new EclipseAgentData("Agent 047", "Engineer", 7) { hp = 90, armor = 85, attack = 70, speed = 80 });
        l.Add(new EclipseAgentData("Agent 052", "Stealth", 5) { hp = 80, armor = 55, attack = 100, speed = 120 });
        return l;
    }
}
