#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class EclipseStyledLobbyMenu
{
    [MenuItem("Tools/Project Eclipse/Create Character Select")]
    static void CreateCharacterSelect()
    {
        var go = new GameObject("Eclipse Character Select");
        Undo.RegisterCreatedObjectUndo(go, "Create Character Select");
        var bld = go.AddComponent<EclipseCharacterSelectBuilder>();
        if (go.transform.Find("EclipseCharacterCanvas_v1") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }

    [MenuItem("Tools/Project Eclipse/Create Game Mode Screen")]
    static void CreateGameMode()
    {
        var go = new GameObject("Eclipse Game Mode");
        Undo.RegisterCreatedObjectUndo(go, "Create Game Mode");
        var bld = go.AddComponent<EclipseGameModeBuilder>();
        if (go.transform.Find("EclipseGameModeCanvas_v1") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }

    [MenuItem("Tools/Project Eclipse/Create Game HUD")]
    static void CreateGameHud()
    {
        var go = new GameObject("Eclipse Game HUD");
        Undo.RegisterCreatedObjectUndo(go, "Create Game HUD");
        var bld = go.AddComponent<EclipseGameHudBuilder>();
        if (go.transform.Find("EclipseHudCanvas_v1") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }

    [MenuItem("Tools/Project Eclipse/Create Login Register Screen")]
    static void CreateAuth()
    {
        var go = new GameObject("Eclipse Login Register");
        Undo.RegisterCreatedObjectUndo(go, "Create Login Register");
        var bld = go.AddComponent<EclipseAuthBuilder>();
        if (go.transform.Find("EclipseAuthCanvas_v1") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }

    [MenuItem("Tools/Project Eclipse/Create Agent Database")]
    static void CreateAgentDatabase()
    {
        const string path = "Assets/EclipseLobby/EclipseAgentDatabase.asset";
        var existing = AssetDatabase.LoadAssetAtPath<EclipseAgentDatabase>(path);
        if (existing != null) { Selection.activeObject = existing; EditorGUIUtility.PingObject(existing); return; }
        var db = ScriptableObject.CreateInstance<EclipseAgentDatabase>();
        db.agents = EclipseAgentDatabase.CreateDefaults();
        AssetDatabase.CreateAsset(db, path);
        AssetDatabase.SaveAssets();
        Selection.activeObject = db;
        EditorGUIUtility.PingObject(db);
    }

    [MenuItem("Tools/Project Eclipse/Create Styled Lobby")]
    static void Create()
    {
        var go = new GameObject("Eclipse Styled Lobby");
        Undo.RegisterCreatedObjectUndo(go, "Create Styled Lobby");
        var bld = go.AddComponent<EclipseStyledLobbyBuilder>(); if (go.transform.Find("EclipseLobbyCanvas_v2") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }
}

[CustomEditor(typeof(EclipseStyledLobbyBuilder))]
public class EclipseStyledLobbyInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Lobby dibangun ulang otomatis setiap Play. Tombol di bawah hanya untuk pratinjau di editor " +
            "(pratinjau tidak ikut tersimpan ke scene).",
            MessageType.Info);
        if (GUILayout.Button("BUILD STYLED LOBBY"))
        {
            var b = (EclipseStyledLobbyBuilder)target;
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Styled Lobby");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
    }
}

[CustomEditor(typeof(EclipseCharacterSelectBuilder))]
public class EclipseCharacterSelectInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Layar dibangun langsung di editor. Isi sprite / daftar agen, lalu klik BUILD untuk membangun ulang " +
            "(hasil edit manual di hierarki akan diganti). Mengubah data agen saat Play langsung terlihat lewat tombol REFRESH.",
            MessageType.Info);
        var b = (EclipseCharacterSelectBuilder)target;
        if (GUILayout.Button("BUILD CHARACTER SELECT"))
        {
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Character Select");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
        if (GUILayout.Button("REFRESH DATA"))
        {
            b.Refresh();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
    }
}

[CustomEditor(typeof(EclipseGameModeBuilder))]
public class EclipseGameModeInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Layar dibangun langsung di editor. Setelah mengisi sprite atau mengubah teks, klik BUILD untuk membangun ulang " +
            "(hasil edit manual di hierarki akan diganti). REFRESH DATA hanya memperbarui isi daftar mode.",
            MessageType.Info);
        var b = (EclipseGameModeBuilder)target;
        if (GUILayout.Button("BUILD GAME MODE"))
        {
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Game Mode");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
        if (GUILayout.Button("REFRESH DATA"))
        {
            b.Refresh();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
    }
}

[CustomEditor(typeof(EclipseGameHudBuilder))]
public class EclipseGameHudInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "HUD dibangun langsung di editor. Setelah mengisi sprite, klik BUILD untuk membangun ulang " +
            "(hasil edit manual di hierarki akan diganti). Nilai status (HP, amunisi, kompas, timer) memperbarui UI otomatis saat Play.",
            MessageType.Info);
        var b = (EclipseGameHudBuilder)target;
        if (GUILayout.Button("BUILD GAME HUD"))
        {
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Game HUD");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
        if (GUILayout.Button("REFRESH DATA"))
        {
            b.Refresh();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
    }
}

[CustomEditor(typeof(EclipseAuthBuilder))]
public class EclipseAuthInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Layar Login/Register dibangun langsung di editor. Klik BUILD setelah mengisi sprite (hasil edit manual akan diganti). " +
            "Tombol Show Login / Show Register hanya mengganti tab yang terlihat di editor. " +
            "Akun lokal hanya untuk uji coba; untuk produksi matikan dan hubungkan event On Login / On Register ke servermu.",
            MessageType.Info);
        var b = (EclipseAuthBuilder)target;
        if (GUILayout.Button("BUILD LOGIN / REGISTER"))
        {
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Login Register");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("SHOW LOGIN")) { b.ShowLogin(); if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene); }
        if (GUILayout.Button("SHOW REGISTER")) { b.ShowRegister(); if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene); }
        EditorGUILayout.EndHorizontal();
    }
}
#endif
