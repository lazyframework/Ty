using UnityEngine;
using UnityEngine.EventSystems;

// Seret di area karakter untuk memutar model 3D.
public class EclipseModelDrag : MonoBehaviour, IDragHandler
{
    public EclipseCharacterStage stage;
    public float sensitivity = 0.4f;

    public void OnDrag(PointerEventData e)
    {
        if (stage != null) stage.Rotate(-e.delta.x * sensitivity);
    }
}
