#if ECLIPSE_FIREBASE
using System;
using UnityEngine;
using Firebase;
using Firebase.Auth;
using Firebase.Extensions;

// Menghubungkan layar Login/Register (EclipseAuthBuilder) ke Firebase Authentication.
// Pasang di objek yang sama dengan EclipseAuthBuilder.
// Prasyarat: Firebase Unity SDK (FirebaseAuth) sudah diimpor, google-services.json /
// GoogleService-Info.plist sudah ada di Assets, dan simbol ECLIPSE_FIREBASE sudah ditambahkan
// di Player Settings > Scripting Define Symbols.
[RequireComponent(typeof(EclipseAuthBuilder))]
public class EclipseFirebaseAuth : MonoBehaviour
{
    [Tooltip("Kalau pemain masih tercatat login, langsung masuk tanpa mengisi form.")]
    public bool autoLoginIfSignedIn = true;
    [Tooltip("Kirim email verifikasi setelah daftar.")]
    public bool sendVerificationEmail = false;
    public string userIdPrefsKey = "EclipseUserId";

    EclipseAuthBuilder ui;
    FirebaseAuth auth;
    bool ready;

    void Awake()
    {
        ui = GetComponent<EclipseAuthBuilder>();
        ui.useLocalDemoAccounts = false;   // jangan pakai akun lokal bersamaan dengan Firebase
        ui.loginWithEmailOnly = true;
        ui.handleGuestExternally = true;
        ui.onLogin.AddListener(Login);
        ui.onRegister.AddListener(Register);
        ui.onGuest.AddListener(Guest);
        ui.onForgotPassword.AddListener(Forgot);
    }

    void OnDestroy()
    {
        if (ui == null) return;
        ui.onLogin.RemoveListener(Login);
        ui.onRegister.RemoveListener(Register);
        ui.onGuest.RemoveListener(Guest);
        ui.onForgotPassword.RemoveListener(Forgot);
    }

    void Start()
    {
        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(t =>
        {
            if (t.Result != DependencyStatus.Available)
            {
                ui.ShowError("Cannot connect to server (" + t.Result + ").");
                return;
            }
            auth = FirebaseAuth.DefaultInstance;
            ready = true;
            if (autoLoginIfSignedIn && auth.CurrentUser != null && !auth.CurrentUser.IsAnonymous)
                Done(auth.CurrentUser, null);
        });
    }

    // ------------------------------------------------------------ aksi

    void Login(string email, string password)
    {
        if (!Ready()) return;
        ui.ShowInfo("Signing in...");
        auth.SignInWithEmailAndPasswordAsync(email, password).ContinueWithOnMainThread(t =>
        {
            if (t.IsCanceled) { ui.ShowError("Sign in was cancelled."); return; }
            if (t.IsFaulted) { ui.ShowError(Friendly(t.Exception)); return; }
            Done(t.Result.User, null);
        });
    }

    void Register(string username, string email, string password)
    {
        if (!Ready()) return;
        ui.ShowInfo("Creating account...");
        auth.CreateUserWithEmailAndPasswordAsync(email, password).ContinueWithOnMainThread(t =>
        {
            if (t.IsCanceled) { ui.ShowError("Registration was cancelled."); return; }
            if (t.IsFaulted) { ui.ShowError(Friendly(t.Exception)); return; }
            var user = t.Result.User;
            if (sendVerificationEmail) user.SendEmailVerificationAsync();
            EclipsePlayerData.SetName(username);   // nama pilihan pemain masuk ke profil realtime
            user.UpdateUserProfileAsync(new UserProfile { DisplayName = username }).ContinueWithOnMainThread(p =>
            {
                Done(user, username);
            });
        });
    }

    void Guest()
    {
        if (!Ready()) return;
        ui.ShowInfo("Signing in as guest...");
        auth.SignInAnonymouslyAsync().ContinueWithOnMainThread(t =>
        {
            if (t.IsCanceled || t.IsFaulted) { ui.ShowError(t.IsFaulted ? Friendly(t.Exception) : "Cancelled."); return; }
            Done(t.Result.User, "Guest");
        });
    }

    void Forgot()
    {
        if (!Ready()) return;
        string email = ui.LoginIdentityText.Trim();
        if (string.IsNullOrEmpty(email) || !email.Contains("@"))
        {
            ui.ShowError("Enter your email in the field above first.");
            return;
        }
        auth.SendPasswordResetEmailAsync(email).ContinueWithOnMainThread(t =>
        {
            if (t.IsCanceled) return;
            if (t.IsFaulted) { ui.ShowError(Friendly(t.Exception)); return; }
            ui.ShowInfo("Password reset email sent to " + email + ".");
        });
    }

    public void SignOut()
    {
        if (auth != null) auth.SignOut();
        PlayerPrefs.DeleteKey(ui.playerNamePrefsKey);
        PlayerPrefs.DeleteKey(userIdPrefsKey);
    }

    // ------------------------------------------------------------ util

    bool Ready()
    {
        if (ready) return true;
        ui.ShowError("Connecting to server, please wait...");
        return false;
    }

    void Done(FirebaseUser user, string nameOverride)
    {
        if (!string.IsNullOrEmpty(userIdPrefsKey)) PlayerPrefs.SetString(userIdPrefsKey, user.UserId);
        string n = nameOverride;
        if (string.IsNullOrEmpty(n)) n = user.DisplayName;
        if (string.IsNullOrEmpty(n) && !string.IsNullOrEmpty(user.Email)) n = user.Email.Split('@')[0];
        if (string.IsNullOrEmpty(n)) n = "Agent";
        ui.Success(n);
    }

    static string Friendly(Exception ex)
    {
        var fe = ex != null ? ex.GetBaseException() as FirebaseException : null;
        if (fe == null) return ex != null ? ex.GetBaseException().Message : "Unknown error.";
        switch ((AuthError)fe.ErrorCode)
        {
            case AuthError.EmailAlreadyInUse: return "Email is already registered.";
            case AuthError.InvalidEmail: return "Invalid email address.";
            case AuthError.MissingEmail: return "Enter your email.";
            case AuthError.MissingPassword: return "Enter your password.";
            case AuthError.WrongPassword: return "Wrong password.";
            case AuthError.UserNotFound: return "Account not found.";
            case AuthError.WeakPassword: return "Password is too weak.";
            case AuthError.UserDisabled: return "This account has been disabled.";
            case AuthError.TooManyRequests: return "Too many attempts. Try again later.";
            case AuthError.NetworkRequestFailed: return "No internet connection.";
        }
        return fe.Message;
    }
}
#endif
