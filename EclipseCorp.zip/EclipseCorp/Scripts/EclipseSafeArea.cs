using UnityEngine;

// Menjaga UI tidak terpotong notch / kamera depan / sudut layar melengkung.
// Dipasang otomatis di ReferenceFrame. Latar (BackdropRoot) tetap memenuhi seluruh layar.
[ExecuteAlways]
public class EclipseSafeArea : MonoBehaviour
{
    Rect last;
    Vector2Int lastScreen;

    void OnEnable() { Apply(true); }
    void Update() { Apply(false); }

    void Apply(bool force)
    {
        var rt = transform as RectTransform;
        if (rt == null || Screen.width <= 0 || Screen.height <= 0) return;
        var sa = Screen.safeArea;
        if (!force && sa == last && lastScreen.x == Screen.width && lastScreen.y == Screen.height) return;
        last = sa;
        lastScreen = new Vector2Int(Screen.width, Screen.height);
        Vector2 min = sa.position, max = sa.position + sa.size;
        min.x /= Screen.width; min.y /= Screen.height;
        max.x /= Screen.width; max.y /= Screen.height;
        rt.anchorMin = min;
        rt.anchorMax = max;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }
}
