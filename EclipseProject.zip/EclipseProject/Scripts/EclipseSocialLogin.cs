#if ECLIPSE_FIREBASE
using System;
using System.Collections.Generic;
using UnityEngine;
using Firebase.Auth;
using Firebase.Extensions;
#if ECLIPSE_GOOGLE
using Google;
#endif
#if ECLIPSE_FACEBOOK
using Facebook.Unity;
#endif

// Login Google & Facebook -> Firebase Authentication.
// Pasang di objek yang sama dengan EclipseAuthBuilder. Tombol Google/Facebook di layar awal
// memanggil event onGoogle / onFacebook, yang dihubungkan otomatis di Awake().
public class EclipseSocialLogin : MonoBehaviour
{
    public EclipseAuthBuilder ui;
    [Tooltip("Web client ID dari Firebase Console > Authentication > Google.")]
    public string googleWebClientId = "ISI_WEB_CLIENT_ID.apps.googleusercontent.com";
    public string userIdPrefsKey = "EclipseUserId";

    void Awake()
    {
        if (ui == null) ui = GetComponent<EclipseAuthBuilder>();
        ui.onGoogle.AddListener(GoogleLogin);
        ui.onFacebook.AddListener(FacebookLogin);
    }

    void OnDestroy()
    {
        if (ui == null) return;
        ui.onGoogle.RemoveListener(GoogleLogin);
        ui.onFacebook.RemoveListener(FacebookLogin);
    }

    void Start()
    {
#if ECLIPSE_FACEBOOK
        if (!FB.IsInitialized)
            FB.Init(() => { if (FB.IsInitialized) FB.ActivateApp(); });
#endif
    }

    public void GoogleLogin()
    {
#if ECLIPSE_GOOGLE
        GoogleSignIn.Configuration = new GoogleSignInConfiguration
        {
            WebClientId = googleWebClientId,
            RequestIdToken = true
        };
        ui.ShowInfo("Signing in with Google...");
        GoogleSignIn.DefaultInstance.SignIn().ContinueWithOnMainThread(t =>
        {
            if (t.IsCanceled) { ui.ShowError("Login Google dibatalkan."); return; }
            if (t.IsFaulted) { ui.ShowError(t.Exception.GetBaseException().Message); return; }

            var cred = GoogleAuthProvider.GetCredential(t.Result.IdToken, null);
            SignIn(cred);
        });
#else
        ui.ShowError("Login Google belum diaktifkan (ECLIPSE_GOOGLE).");
#endif
    }

    public void FacebookLogin()
    {
#if ECLIPSE_FACEBOOK
        if (!FB.IsInitialized) { ui.ShowError("Facebook belum siap, coba lagi."); return; }
        ui.ShowInfo("Signing in with Facebook...");
        FB.LogInWithReadPermissions(new List<string> { "public_profile", "email" }, r =>
        {
            if (r.Error != null || !FB.IsLoggedIn) { ui.ShowError("Login Facebook gagal."); return; }

            var cred = FacebookAuthProvider.GetCredential(AccessToken.CurrentAccessToken.TokenString);
            SignIn(cred);
        });
#else
        ui.ShowError("Login Facebook belum diaktifkan (ECLIPSE_FACEBOOK).");
#endif
    }

    void SignIn(Credential cred)
    {
        FirebaseAuth.DefaultInstance.SignInWithCredentialAsync(cred).ContinueWithOnMainThread(t =>
        {
            if (t.IsCanceled) { ui.ShowError("Login dibatalkan."); return; }
            if (t.IsFaulted) { ui.ShowError(t.Exception.GetBaseException().Message); return; }

            var user = t.Result;
            PlayerPrefs.SetString(userIdPrefsKey, user.UserId);
            string n = !string.IsNullOrEmpty(user.DisplayName)
                ? user.DisplayName
                : (!string.IsNullOrEmpty(user.Email) ? user.Email.Split('@')[0] : "Agent");
            ui.Success(n);
        });
    }
}
#endif
